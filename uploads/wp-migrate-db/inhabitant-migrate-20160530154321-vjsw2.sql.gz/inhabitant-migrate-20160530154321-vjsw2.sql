# WordPress MySQL database migration
#
# Generated: Monday 30. May 2016 15:43 UTC
# Hostname: localhost
# Database: `inhabitant`
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_cfs_sessions`
#

DROP TABLE IF EXISTS `wp_cfs_sessions`;


#
# Table structure of table `wp_cfs_sessions`
#

CREATE TABLE `wp_cfs_sessions` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `data` text,
  `expires` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_cfs_sessions`
#
INSERT INTO `wp_cfs_sessions` ( `id`, `data`, `expires`) VALUES
('0d17bc4b344e55265aab924d23b81fe9', 'a:7:{s:7:"post_id";i:40;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:39;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464635455'),
('0ec4b3ae5876ce0e5b2e19d9b1030258', 'a:7:{s:7:"post_id";i:40;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:39;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464635636'),
('10c0e0769c5406eb3da5af91f3efec06', 'a:7:{s:7:"post_id";i:40;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:39;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464635979'),
('134097adf412befd3d7eff999299a8b1', 'a:7:{s:7:"post_id";i:40;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:39;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464635870'),
('32a679814e8ca157bf9cad17824f44d0', 'a:7:{s:7:"post_id";i:40;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:39;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464635637'),
('3e42bd3619a75007fe98fd20a286eded', 'a:7:{s:7:"post_id";i:40;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:39;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464635979'),
('494ac79623392d4d691ad2ee2ffbc241', 'a:7:{s:7:"post_id";i:40;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:39;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464635780'),
('4fdcfe17091fb66b0b8483a3da1296b8', 'a:7:{s:7:"post_id";i:40;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:39;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464635780'),
('5b7c8cf615004877d76e6b8bf1fac634', 'a:7:{s:7:"post_id";i:40;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:39;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464635881'),
('60ab921e65b7c7bd52e260d753c7baff', 'a:7:{s:7:"post_id";i:40;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:39;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464635980'),
('67454bcbb1743f88bf24efd8fe07b4aa', 'a:7:{s:7:"post_id";i:40;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:39;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464635454'),
('6bac57b73aa1b54729533594515049ed', 'a:7:{s:7:"post_id";i:40;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:39;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464635456'),
('7545fe8e4128066a9df7f2be666626c3', 'a:7:{s:7:"post_id";i:40;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:39;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464635720'),
('88deb974b2a80b3df129d1980700d7ca', 'a:7:{s:7:"post_id";i:40;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:39;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464635509'),
('9a69480b987f60ec39160633f6835522', 'a:7:{s:7:"post_id";i:40;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:39;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464635943'),
('9f975725c836ba7b33c5a6d4b1b5d1bf', 'a:7:{s:7:"post_id";i:40;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:39;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464635509'),
('b534cae09d6f45fdc8e3a7342773e3de', 'a:7:{s:7:"post_id";i:40;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:39;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464635942'),
('b76de634409a660d679e9526daf01858', 'a:7:{s:7:"post_id";i:40;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:39;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464635644'),
('c22a0eeb594d92702d59134c935e4591', 'a:7:{s:7:"post_id";i:40;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:39;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464635782'),
('e0bb013d03c52a54f1bd072211e2df61', 'a:7:{s:7:"post_id";i:40;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:39;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464635642'),
('ff7979442861a40372a694aa8f4e8529', 'a:7:{s:7:"post_id";i:40;s:9:"post_type";s:4:"post";s:11:"post_status";s:5:"draft";s:12:"field_groups";a:1:{i:0;i:39;}s:20:"confirmation_message";s:0:"";s:16:"confirmation_url";s:0:"";s:9:"front_end";b:0;}', '1464635929') ;

#
# End of data contents of table `wp_cfs_sessions`
# --------------------------------------------------------



#
# Delete any existing table `wp_cfs_values`
#

DROP TABLE IF EXISTS `wp_cfs_values`;


#
# Table structure of table `wp_cfs_values`
#

CREATE TABLE `wp_cfs_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `field_id` int(10) unsigned DEFAULT NULL,
  `meta_id` int(10) unsigned DEFAULT NULL,
  `post_id` int(10) unsigned DEFAULT NULL,
  `base_field_id` int(10) unsigned DEFAULT '0',
  `hierarchy` text,
  `depth` int(10) unsigned DEFAULT '0',
  `weight` int(10) unsigned DEFAULT '0',
  `sub_weight` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `field_id_idx` (`field_id`),
  KEY `post_id_idx` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_cfs_values`
#
INSERT INTO `wp_cfs_values` ( `id`, `field_id`, `meta_id`, `post_id`, `base_field_id`, `hierarchy`, `depth`, `weight`, `sub_weight`) VALUES
(3, 1, 77, 35, 0, '', 0, 0, 0),
(6, 1, 99, 47, 0, '', 0, 0, 0),
(8, 1, 137, 50, 0, '', 0, 0, 0),
(9, 1, 141, 67, 0, '', 0, 0, 0),
(10, 1, 145, 69, 0, '', 0, 0, 0),
(21, 1, 178, 91, 0, '', 0, 0, 0),
(22, 1, 319, 89, 0, '', 0, 0, 0),
(23, 1, 321, 85, 0, '', 0, 0, 0),
(24, 1, 323, 87, 0, '', 0, 0, 0),
(25, 1, 325, 83, 0, '', 0, 0, 0),
(26, 1, 327, 81, 0, '', 0, 0, 0),
(27, 1, 329, 79, 0, '', 0, 0, 0),
(28, 1, 331, 77, 0, '', 0, 0, 0),
(29, 1, 333, 75, 0, '', 0, 0, 0),
(30, 1, 335, 73, 0, '', 0, 0, 0),
(31, 1, 337, 71, 0, '', 0, 0, 0),
(32, 1, 341, 135, 0, '', 0, 0, 0),
(91, 2, 415, 40, 0, '', 0, 0, 0),
(92, 3, 416, 40, 0, '', 0, 0, 0),
(93, 5, 417, 40, 0, '', 0, 0, 0) ;

#
# End of data contents of table `wp_cfs_values`
# --------------------------------------------------------



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2016-05-19 20:01:11', '2016-05-19 20:01:11', 'Hi, this is a comment.\nTo delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, 'post-trashed', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=528 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/student', 'yes'),
(2, 'home', 'http://localhost/student', 'yes'),
(3, 'blogname', 'inhabitents', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'hunter_w@live.ca', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '16', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '16', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:133:{s:11:"products/?$";s:27:"index.php?post_type=product";s:41:"products/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:36:"products/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:28:"products/page/([0-9]{1,})/?$";s:45:"index.php?post_type=product&paged=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:35:"product/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"product/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"product/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"product/([^/]+)/embed/?$";s:40:"index.php?product=$matches[1]&embed=true";s:28:"product/([^/]+)/trackback/?$";s:34:"index.php?product=$matches[1]&tb=1";s:48:"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:43:"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:36:"product/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&paged=$matches[2]";s:43:"product/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&cpage=$matches[2]";s:32:"product/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?product=$matches[1]&page=$matches[2]";s:24:"product/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"product/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"product/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"product-type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?product-type=$matches[1]&feed=$matches[2]";s:48:"product-type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?product-type=$matches[1]&feed=$matches[2]";s:29:"product-type/([^/]+)/embed/?$";s:45:"index.php?product-type=$matches[1]&embed=true";s:41:"product-type/([^/]+)/page/?([0-9]{1,})/?$";s:52:"index.php?product-type=$matches[1]&paged=$matches[2]";s:23:"product-type/([^/]+)/?$";s:34:"index.php?product-type=$matches[1]";s:31:"cfs/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:41:"cfs/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:61:"cfs/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"cfs/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"cfs/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:37:"cfs/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:20:"cfs/([^/]+)/embed/?$";s:51:"index.php?post_type=cfs&name=$matches[1]&embed=true";s:24:"cfs/([^/]+)/trackback/?$";s:45:"index.php?post_type=cfs&name=$matches[1]&tb=1";s:32:"cfs/([^/]+)/page/?([0-9]{1,})/?$";s:58:"index.php?post_type=cfs&name=$matches[1]&paged=$matches[2]";s:39:"cfs/([^/]+)/comment-page-([0-9]{1,})/?$";s:58:"index.php?post_type=cfs&name=$matches[1]&cpage=$matches[2]";s:28:"cfs/([^/]+)(?:/([0-9]+))?/?$";s:57:"index.php?post_type=cfs&name=$matches[1]&page=$matches[2]";s:20:"cfs/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:30:"cfs/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:50:"cfs/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:"cfs/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:"cfs/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:26:"cfs/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:40:"index.php?&page_id=120&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:7:{i:0;s:47:"business-hours-widget/business-hours-widget.php";i:1;s:36:"contact-form-7/wp-contact-form-7.php";i:2;s:26:"custom-field-suite/cfs.php";i:3;s:52:"inhabitent-functionality/inhabitent-functionalty.php";i:4;s:19:"rest-api/plugin.php";i:5;s:27:"theme-check/theme-check.php";i:6;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'inhabitent', 'yes'),
(41, 'stylesheet', 'inhabitent', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '36686', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:3:{i:1;a:0:{}i:2;a:3:{s:5:"title";s:12:"Contact Info";s:4:"text";s:410:"<p>\r\n							<i class="fa fa-envelope"></i>\r\n							<a href="mailto:info@inhabitent.com">info@inhabitent.com</a>\r\n							</p>\r\n							<p>\r\n								<i class="fa fa-phone"></i>\r\n								<a href="#">778-456-7891</a>\r\n							</p>\r\n							<p>\r\n								<i class="fa fa-facebook-square fa-lg"></i>\r\n								<i class="fa fa-twitter-square fa-lg"></i>\r\n								<i class="fa fa-google-plus-square fa-lg"></i>\r\n							</p>";s:6:"filter";b:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '118', 'yes'),
(84, 'page_on_front', '120', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '36686', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:6:"text-2";i:1;s:18:"inhabitent-hours-2";i:2;s:10:"archives-2";}s:13:"array_version";i:3;}', 'yes'),
(99, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'cron', 'a:4:{i:1464638472;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1464638489;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1464647732;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(106, 'nonce_key', 'm:v0JIqK1<W5ZkRt^)FvrWsi{EBIos,uP%)@R-!K {O:d6GBdL$u:}GRbO?) &=}', 'yes'),
(107, 'nonce_salt', '-tqJc8S??M>hwD A9Dr;FQj44T1asuEp7[_qoG(bx/lk&s8:DN|TsP.Dpx93aBz$', 'yes'),
(116, 'auth_key', 'pt#4pJ2ka[ZZlj=.{Y-u<KUISBka1-<+pt~@^bqEWt V~9]44%7J0`r-I8,S#0lh', 'yes'),
(117, 'auth_salt', 'yr[@Ja4xc,z$0wU4CXnFsBOSOUXl`NN4! 0oeP]9OmI!tHdsN.hm&,etuBTDy/!i', 'yes'),
(118, 'logged_in_key', 'uW0&/J2f!:]a6!MH|x ain[b0*%Nqn1S^IiXF*~<;g5by~AN%TMp{iiQUmXHAc^Z', 'yes'),
(119, 'logged_in_salt', 'kWmYP-yQGc}7(A2K9g}tT!3N19~}U.XNWnAS7eI<^![VsHD/#{iAcc w_F)>CYl#', 'yes'),
(123, 'can_compress_scripts', '1', 'yes'),
(141, 'current_theme', 'Inhabitents', 'yes'),
(142, 'theme_mods_redstarter-master', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1463694435;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(143, 'theme_switched', '', 'yes'),
(147, 'theme_mods_inhabitent_theme', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1464118639;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(177, 'category_children', 'a:0:{}', 'yes'),
(200, 'recently_activated', 'a:0:{}', 'yes'),
(238, 'theme_mods_twentysixteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1464118651;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(239, 'theme_mods_inhabitent', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:7:"primary";i:20;}}', 'yes'),
(262, 'cfs_next_field_id', '6', 'yes'),
(263, 'cfs_version', '2.5.5', 'yes'),
(316, 'product-type_children', 'a:0:{}', 'yes'),
(340, 'widget_inhabitent-hours', 'a:2:{i:2;a:4:{s:5:"title";s:14:"Business Hours";s:13:"monday_friday";s:7:"9am-5pm";s:8:"saturday";s:8:"10am-2pm";s:6:"sunday";s:6:"closed";}s:12:"_multiwidget";i:1;}', 'yes'),
(452, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(468, 'wpcf7', 'a:2:{s:7:"version";s:5:"4.4.2";s:13:"bulk_validate";a:4:{s:9:"timestamp";i:1464566532;s:7:"version";s:5:"4.4.2";s:11:"count_valid";i:1;s:13:"count_invalid";i:0;}}', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=418 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 6, '_wp_attached_file', '2016/05/van-camper.jpg'),
(3, 6, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:1026;s:4:"file";s:22:"2016/05/van-camper.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"van-camper-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"van-camper-300x205.jpg";s:5:"width";i:300;s:6:"height";i:205;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"van-camper-768x525.jpg";s:5:"width";i:768;s:6:"height";i:525;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"van-camper-1024x700.jpg";s:5:"width";i:1024;s:6:"height";i:700;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(4, 5, '_thumbnail_id', '6'),
(5, 5, '_edit_last', '1'),
(6, 5, '_edit_lock', '1464303787:1'),
(9, 8, '_edit_last', '1'),
(10, 8, '_edit_lock', '1463701256:1'),
(11, 10, '_wp_attached_file', '2016/05/warm-cocktail.jpg'),
(12, 10, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:25:"2016/05/warm-cocktail.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"warm-cocktail-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"warm-cocktail-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"warm-cocktail-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"warm-cocktail-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(13, 8, '_thumbnail_id', '10'),
(32, 20, '_edit_last', '1'),
(33, 20, '_edit_lock', '1463705293:1'),
(34, 21, '_edit_last', '1'),
(35, 21, '_edit_lock', '1463705330:1'),
(36, 22, '_wp_attached_file', '2016/05/healthy-camp-food.jpg'),
(37, 22, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:29:"2016/05/healthy-camp-food.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"healthy-camp-food-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"healthy-camp-food-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:29:"healthy-camp-food-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:30:"healthy-camp-food-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(38, 20, '_thumbnail_id', '22'),
(43, 21, '_wp_trash_meta_status', 'publish'),
(44, 21, '_wp_trash_meta_time', '1463705510'),
(45, 21, '_wp_desired_post_slug', 'how-to-eating-healthy-meals-in-the-wild-2'),
(46, 1, '_wp_trash_meta_status', 'publish'),
(47, 1, '_wp_trash_meta_time', '1463705545'),
(48, 1, '_wp_desired_post_slug', 'hello-world'),
(49, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}'),
(50, 26, '_edit_last', '1'),
(51, 26, '_edit_lock', '1464303818:1'),
(52, 27, '_wp_attached_file', '2016/05/solo-camping.jpg'),
(53, 27, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2515;s:6:"height";i:1830;s:4:"file";s:24:"2016/05/solo-camping.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"solo-camping-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"solo-camping-300x218.jpg";s:5:"width";i:300;s:6:"height";i:218;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"solo-camping-768x559.jpg";s:5:"width";i:768;s:6:"height";i:559;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"solo-camping-1024x745.jpg";s:5:"width";i:1024;s:6:"height";i:745;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(54, 26, '_thumbnail_id', '27'),
(57, 29, '_edit_last', '1'),
(58, 29, '_edit_lock', '1464555946:1'),
(59, 30, '_wp_attached_file', '2016/05/glamping.jpg'),
(60, 30, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:20:"2016/05/glamping.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"glamping-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"glamping-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"glamping-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"glamping-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(61, 29, '_thumbnail_id', '30'),
(64, 2, '_edit_lock', '1464555670:1'),
(65, 2, '_edit_last', '1'),
(66, 33, '_edit_last', '1'),
(67, 33, '_edit_lock', '1464551262:1'),
(68, 35, '_edit_last', '1'),
(69, 35, '_edit_lock', '1464129516:1'),
(70, 37, '_edit_last', '1'),
(71, 37, '_edit_lock', '1464126879:1'),
(72, 37, 'cfs_fields', 'a:1:{i:0;a:8:{s:2:"id";i:1;s:4:"name";s:5:"price";s:5:"label";s:5:"Price";s:4:"type";s:4:"text";s:5:"notes";s:29:"Enter a price for the product";s:9:"parent_id";i:0;s:6:"weight";i:0;s:7:"options";a:2:{s:13:"default_value";s:0:"";s:8:"required";s:1:"0";}}}'),
(73, 37, 'cfs_rules', 'a:1:{s:10:"post_types";a:2:{s:8:"operator";s:2:"==";s:6:"values";a:1:{i:0;s:7:"product";}}}'),
(74, 37, 'cfs_extras', 'a:3:{s:5:"order";s:1:"0";s:7:"context";s:6:"normal";s:11:"hide_editor";s:1:"0";}'),
(77, 35, 'price', 'Free'),
(78, 38, '_edit_last', '1'),
(79, 38, '_edit_lock', '1464582914:1'),
(80, 39, '_edit_last', '1'),
(81, 39, '_edit_lock', '1464620908:1'),
(82, 39, 'cfs_fields', 'a:3:{i:0;a:8:{s:2:"id";s:1:"2";s:4:"name";s:11:"splash_hero";s:5:"label";s:11:"Splash Hero";s:4:"type";s:4:"file";s:5:"notes";s:20:"Image for About page";s:9:"parent_id";i:0;s:6:"weight";i:0;s:7:"options";a:2:{s:12:"return_value";s:3:"url";s:8:"required";s:1:"0";}}i:1;a:8:{s:2:"id";s:1:"3";s:4:"name";s:9:"our_story";s:5:"label";s:9:"Our Story";s:4:"type";s:7:"wysiwyg";s:5:"notes";s:0:"";s:9:"parent_id";i:0;s:6:"weight";i:1;s:7:"options";a:2:{s:10:"formatting";s:7:"default";s:8:"required";s:1:"0";}}i:2;a:8:{s:2:"id";s:1:"5";s:4:"name";s:8:"our_team";s:5:"label";s:8:"Our Team";s:4:"type";s:7:"wysiwyg";s:5:"notes";s:0:"";s:9:"parent_id";i:0;s:6:"weight";i:2;s:7:"options";a:2:{s:10:"formatting";s:7:"default";s:8:"required";s:1:"0";}}}'),
(83, 39, 'cfs_rules', 'a:1:{s:14:"page_templates";a:2:{s:8:"operator";s:2:"==";s:6:"values";a:1:{i:0;s:14:"page-about.php";}}}'),
(84, 39, 'cfs_extras', 'a:3:{s:5:"order";s:1:"0";s:7:"context";s:6:"normal";s:11:"hide_editor";s:1:"0";}'),
(85, 40, '_edit_last', '1'),
(86, 40, '_edit_lock', '1464621446:1'),
(87, 40, '_wp_page_template', 'page-about.php'),
(88, 42, '_wp_attached_file', '2016/05/about-hero.jpg'),
(89, 42, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:4000;s:6:"height";i:2667;s:4:"file";s:22:"2016/05/about-hero.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"about-hero-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"about-hero-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"about-hero-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"about-hero-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(90, 43, '_wp_attached_file', '2016/05/about-hero-1.jpg'),
(91, 43, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:4000;s:6:"height";i:2667;s:4:"file";s:24:"2016/05/about-hero-1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"about-hero-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"about-hero-1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"about-hero-1-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"about-hero-1-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(93, 47, '_edit_last', '1'),
(94, 47, '_edit_lock', '1464557378:1'),
(96, 49, '_wp_attached_file', '2016/05/beach-tent.jpg'),
(97, 49, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1950;s:4:"file";s:22:"2016/05/beach-tent.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"beach-tent-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"beach-tent-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"beach-tent-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"beach-tent-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(98, 47, '_thumbnail_id', '49'),
(99, 47, 'price', '$155.00'),
(100, 35, '_wp_trash_meta_status', 'publish'),
(101, 35, '_wp_trash_meta_time', '1464213872'),
(102, 35, '_wp_desired_post_slug', 'test-product'),
(103, 50, '_edit_last', '1'),
(104, 50, '_edit_lock', '1464557372:1'),
(106, 52, '_wp_attached_file', '2016/05/camper-van.jpg'),
(107, 52, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1125;s:4:"file";s:22:"2016/05/camper-van.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"camper-van-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"camper-van-300x169.jpg";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"camper-van-768x432.jpg";s:5:"width";i:768;s:6:"height";i:432;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"camper-van-1024x576.jpg";s:5:"width";i:1024;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(108, 53, '_wp_attached_file', '2016/05/ceramic-mugs.jpg'),
(109, 53, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:24:"2016/05/ceramic-mugs.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"ceramic-mugs-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"ceramic-mugs-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"ceramic-mugs-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"ceramic-mugs-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(110, 54, '_wp_attached_file', '2016/05/film-cameras.jpg'),
(111, 54, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1950;s:4:"file";s:24:"2016/05/film-cameras.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"film-cameras-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"film-cameras-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"film-cameras-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"film-cameras-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(112, 55, '_wp_attached_file', '2016/05/flannel-shirt.jpg'),
(113, 55, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1722;s:4:"file";s:25:"2016/05/flannel-shirt.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"flannel-shirt-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"flannel-shirt-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"flannel-shirt-768x509.jpg";s:5:"width";i:768;s:6:"height";i:509;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"flannel-shirt-1024x678.jpg";s:5:"width";i:1024;s:6:"height";i:678;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(114, 56, '_wp_attached_file', '2016/05/gas-stove.jpg'),
(115, 56, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1722;s:4:"file";s:21:"2016/05/gas-stove.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"gas-stove-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"gas-stove-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"gas-stove-768x509.jpg";s:5:"width";i:768;s:6:"height";i:509;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:22:"gas-stove-1024x678.jpg";s:5:"width";i:1024;s:6:"height";i:678;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(116, 57, '_wp_attached_file', '2016/05/hand-knit-toque.jpg'),
(117, 57, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1845;s:4:"file";s:27:"2016/05/hand-knit-toque.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"hand-knit-toque-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"hand-knit-toque-300x213.jpg";s:5:"width";i:300;s:6:"height";i:213;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"hand-knit-toque-768x545.jpg";s:5:"width";i:768;s:6:"height";i:545;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"hand-knit-toque-1024x727.jpg";s:5:"width";i:1024;s:6:"height";i:727;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(118, 58, '_wp_attached_file', '2016/05/hiking-boots.jpg'),
(119, 58, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2376;s:6:"height";i:1782;s:4:"file";s:24:"2016/05/hiking-boots.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"hiking-boots-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"hiking-boots-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"hiking-boots-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"hiking-boots-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(120, 59, '_wp_attached_file', '2016/05/large-thermos.jpg'),
(121, 59, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1722;s:4:"file";s:25:"2016/05/large-thermos.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"large-thermos-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"large-thermos-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:25:"large-thermos-768x509.jpg";s:5:"width";i:768;s:6:"height";i:509;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"large-thermos-1024x678.jpg";s:5:"width";i:1024;s:6:"height";i:678;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(122, 60, '_wp_attached_file', '2016/05/leather-satchel.jpg'),
(123, 60, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:27:"2016/05/leather-satchel.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"leather-satchel-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"leather-satchel-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:27:"leather-satchel-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"leather-satchel-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(124, 61, '_wp_attached_file', '2016/05/nylon-tents.jpg'),
(125, 61, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1732;s:4:"file";s:23:"2016/05/nylon-tents.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"nylon-tents-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"nylon-tents-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"nylon-tents-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"nylon-tents-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(126, 62, '_wp_attached_file', '2016/05/rustic-tools.jpg'),
(127, 62, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:2111;s:4:"file";s:24:"2016/05/rustic-tools.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"rustic-tools-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"rustic-tools-300x244.jpg";s:5:"width";i:300;s:6:"height";i:244;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"rustic-tools-768x624.jpg";s:5:"width";i:768;s:6:"height";i:624;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"rustic-tools-1024x831.jpg";s:5:"width";i:1024;s:6:"height";i:831;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(128, 63, '_wp_attached_file', '2016/05/stew-can.jpg'),
(129, 63, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:20:"2016/05/stew-can.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"stew-can-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"stew-can-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"stew-can-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"stew-can-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(130, 64, '_wp_attached_file', '2016/05/travel-hammock.jpg'),
(131, 64, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2288;s:6:"height";i:1520;s:4:"file";s:26:"2016/05/travel-hammock.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"travel-hammock-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"travel-hammock-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:26:"travel-hammock-768x510.jpg";s:5:"width";i:768;s:6:"height";i:510;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:27:"travel-hammock-1024x680.jpg";s:5:"width";i:1024;s:6:"height";i:680;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(132, 65, '_wp_attached_file', '2016/05/weathered-canoes.jpg'),
(133, 65, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:28:"2016/05/weathered-canoes.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"weathered-canoes-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"weathered-canoes-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:28:"weathered-canoes-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:29:"weathered-canoes-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(134, 66, '_wp_attached_file', '2016/05/wood-ax.jpg'),
(135, 66, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2600;s:6:"height";i:1733;s:4:"file";s:19:"2016/05/wood-ax.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"wood-ax-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"wood-ax-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:19:"wood-ax-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:20:"wood-ax-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(136, 50, '_thumbnail_id', '52'),
(137, 50, 'price', '$2500.00'),
(138, 67, '_edit_last', '1'),
(139, 67, '_edit_lock', '1464557367:1'),
(140, 67, '_thumbnail_id', '53'),
(141, 67, 'price', '$19.00'),
(142, 69, '_edit_last', '1'),
(143, 69, '_edit_lock', '1464557362:1'),
(144, 69, '_thumbnail_id', '54'),
(145, 69, 'price', '$150.00'),
(146, 71, '_edit_last', '1'),
(147, 71, '_edit_lock', '1464557352:1'),
(149, 73, '_edit_last', '1'),
(150, 73, '_edit_lock', '1464557326:1'),
(152, 75, '_edit_last', '1'),
(153, 75, '_edit_lock', '1464557304:1'),
(155, 77, '_edit_last', '1'),
(156, 77, '_edit_lock', '1464557279:1'),
(158, 79, '_edit_last', '1'),
(159, 79, '_edit_lock', '1464557254:1'),
(161, 81, '_edit_last', '1'),
(162, 81, '_edit_lock', '1464557228:1'),
(164, 83, '_edit_last', '1'),
(165, 83, '_edit_lock', '1464557207:1'),
(167, 85, '_edit_last', '1'),
(168, 85, '_edit_lock', '1464557161:1'),
(170, 87, '_edit_last', '1'),
(171, 87, '_edit_lock', '1464557180:1'),
(173, 89, '_edit_last', '1'),
(174, 89, '_edit_lock', '1464557143:1'),
(176, 91, '_edit_last', '1'),
(177, 91, '_edit_lock', '1464219409:1'),
(178, 91, 'price', '$40.00'),
(179, 91, '_thumbnail_id', '66'),
(180, 94, '_edit_last', '1'),
(181, 94, '_edit_lock', '1464551435:1'),
(182, 33, '_wp_trash_meta_status', 'publish'),
(183, 33, '_wp_trash_meta_time', '1464551458'),
(184, 33, '_wp_desired_post_slug', 'home'),
(185, 94, '_wp_page_template', 'default'),
(186, 94, '_wp_trash_meta_status', 'publish'),
(187, 94, '_wp_trash_meta_time', '1464551582'),
(188, 94, '_wp_desired_post_slug', 'journal'),
(189, 111, '_edit_last', '1'),
(190, 111, '_edit_lock', '1464566487:1'),
(191, 111, '_wp_page_template', 'default'),
(192, 108, '_edit_last', '1'),
(193, 108, '_wp_page_template', 'default'),
(194, 108, '_edit_lock', '1464551548:1'),
(195, 108, '_wp_trash_meta_status', 'publish'),
(196, 108, '_wp_trash_meta_time', '1464551699'),
(197, 108, '_wp_desired_post_slug', 'find-us-2'),
(198, 114, '_edit_last', '1'),
(199, 114, '_wp_page_template', 'default'),
(200, 114, '_edit_lock', '1464557035:1'),
(201, 2, '_wp_trash_meta_status', 'publish'),
(202, 2, '_wp_trash_meta_time', '1464555839'),
(203, 2, '_wp_desired_post_slug', 'sample-page'),
(204, 118, '_edit_last', '1'),
(205, 118, '_edit_lock', '1464557750:1'),
(206, 118, '_wp_page_template', 'default'),
(207, 120, '_edit_last', '1'),
(208, 120, '_edit_lock', '1464557738:1'),
(209, 120, '_wp_page_template', 'default'),
(210, 122, '_menu_item_type', 'post_type'),
(211, 122, '_menu_item_menu_item_parent', '0'),
(212, 122, '_menu_item_object_id', '120'),
(213, 122, '_menu_item_object', 'page'),
(214, 122, '_menu_item_target', ''),
(215, 122, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(216, 122, '_menu_item_xfn', ''),
(217, 122, '_menu_item_url', ''),
(218, 122, '_menu_item_orphaned', '1464556691'),
(219, 123, '_menu_item_type', 'post_type'),
(220, 123, '_menu_item_menu_item_parent', '0'),
(221, 123, '_menu_item_object_id', '40'),
(222, 123, '_menu_item_object', 'page'),
(223, 123, '_menu_item_target', ''),
(224, 123, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(225, 123, '_menu_item_xfn', ''),
(226, 123, '_menu_item_url', ''),
(227, 123, '_menu_item_orphaned', '1464556691'),
(228, 124, '_menu_item_type', 'post_type'),
(229, 124, '_menu_item_menu_item_parent', '0'),
(230, 124, '_menu_item_object_id', '111'),
(231, 124, '_menu_item_object', 'page'),
(232, 124, '_menu_item_target', ''),
(233, 124, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(234, 124, '_menu_item_xfn', ''),
(235, 124, '_menu_item_url', ''),
(236, 124, '_menu_item_orphaned', '1464556691'),
(237, 125, '_menu_item_type', 'post_type'),
(238, 125, '_menu_item_menu_item_parent', '0'),
(239, 125, '_menu_item_object_id', '120'),
(240, 125, '_menu_item_object', 'page'),
(241, 125, '_menu_item_target', ''),
(242, 125, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(243, 125, '_menu_item_xfn', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(244, 125, '_menu_item_url', ''),
(245, 125, '_menu_item_orphaned', '1464556691'),
(246, 126, '_menu_item_type', 'post_type'),
(247, 126, '_menu_item_menu_item_parent', '0'),
(248, 126, '_menu_item_object_id', '118'),
(249, 126, '_menu_item_object', 'page'),
(250, 126, '_menu_item_target', ''),
(251, 126, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(252, 126, '_menu_item_xfn', ''),
(253, 126, '_menu_item_url', ''),
(254, 126, '_menu_item_orphaned', '1464556691'),
(255, 127, '_menu_item_type', 'post_type'),
(256, 127, '_menu_item_menu_item_parent', '0'),
(257, 127, '_menu_item_object_id', '114'),
(258, 127, '_menu_item_object', 'page'),
(259, 127, '_menu_item_target', ''),
(260, 127, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(261, 127, '_menu_item_xfn', ''),
(262, 127, '_menu_item_url', ''),
(263, 127, '_menu_item_orphaned', '1464556691'),
(273, 129, '_menu_item_type', 'post_type'),
(274, 129, '_menu_item_menu_item_parent', '0'),
(275, 129, '_menu_item_object_id', '40'),
(276, 129, '_menu_item_object', 'page'),
(277, 129, '_menu_item_target', ''),
(278, 129, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(279, 129, '_menu_item_xfn', ''),
(280, 129, '_menu_item_url', ''),
(282, 130, '_menu_item_type', 'post_type'),
(283, 130, '_menu_item_menu_item_parent', '0'),
(284, 130, '_menu_item_object_id', '111'),
(285, 130, '_menu_item_object', 'page'),
(286, 130, '_menu_item_target', ''),
(287, 130, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(288, 130, '_menu_item_xfn', ''),
(289, 130, '_menu_item_url', ''),
(300, 132, '_menu_item_type', 'post_type'),
(301, 132, '_menu_item_menu_item_parent', '0'),
(302, 132, '_menu_item_object_id', '118'),
(303, 132, '_menu_item_object', 'page'),
(304, 132, '_menu_item_target', ''),
(305, 132, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(306, 132, '_menu_item_xfn', ''),
(307, 132, '_menu_item_url', ''),
(309, 133, '_menu_item_type', 'post_type'),
(310, 133, '_menu_item_menu_item_parent', '0'),
(311, 133, '_menu_item_object_id', '114'),
(312, 133, '_menu_item_object', 'page'),
(313, 133, '_menu_item_target', ''),
(314, 133, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(315, 133, '_menu_item_xfn', ''),
(316, 133, '_menu_item_url', ''),
(318, 89, '_thumbnail_id', '65'),
(319, 89, 'price', '$400.00'),
(320, 85, '_thumbnail_id', '63'),
(321, 85, 'price', '$22.00'),
(322, 87, '_thumbnail_id', '64'),
(323, 87, 'price', '$75.00'),
(324, 83, '_thumbnail_id', '62'),
(325, 83, 'price', '$100.00'),
(326, 81, '_thumbnail_id', '61'),
(327, 81, 'price', '$220.00'),
(328, 79, '_thumbnail_id', '60'),
(329, 79, 'price', '$60.00'),
(330, 77, '_thumbnail_id', '59'),
(331, 77, 'price', '$42.00'),
(332, 75, '_thumbnail_id', '58'),
(333, 75, 'price', '$135.00'),
(334, 73, '_thumbnail_id', '57'),
(335, 73, 'price', '$28.00'),
(336, 71, '_thumbnail_id', '56'),
(337, 71, 'price', '$120.00'),
(338, 135, '_edit_last', '1'),
(339, 135, '_edit_lock', '1464557504:1'),
(340, 135, '_thumbnail_id', '55'),
(341, 135, 'price', '$45.00'),
(364, 137, '_form', '<p>Your Name (required)<br />\n    [text* your-name] </p>\n\n<p>Your Email (required)<br />\n    [email* your-email] </p>\n\n<p>Subject<br />\n    [text your-subject] </p>\n\n<p>Your Message<br />\n    [textarea your-message] </p>\n\n<p>[submit "Send"]</p>'),
(365, 137, '_mail', 'a:8:{s:7:"subject";s:28:"inhabitents "[your-subject]"";s:6:"sender";s:30:"[your-name] <hunter_w@live.ca>";s:4:"body";s:173:"From: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n--\nThis e-mail was sent from a contact form on inhabitents (http://localhost/student)";s:9:"recipient";s:16:"hunter_w@live.ca";s:18:"additional_headers";s:22:"Reply-To: [your-email]";s:11:"attachments";s:0:"";s:8:"use_html";i:0;s:13:"exclude_blank";i:0;}'),
(366, 137, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:28:"inhabitents "[your-subject]"";s:6:"sender";s:30:"inhabitents <hunter_w@live.ca>";s:4:"body";s:115:"Message Body:\n[your-message]\n\n--\nThis e-mail was sent from a contact form on inhabitents (http://localhost/student)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:26:"Reply-To: hunter_w@live.ca";s:11:"attachments";s:0:"";s:8:"use_html";i:0;s:13:"exclude_blank";i:0;}'),
(367, 137, '_messages', 'a:8:{s:12:"mail_sent_ok";s:45:"Thank you for your message. It has been sent.";s:12:"mail_sent_ng";s:71:"There was an error trying to send your message. Please try again later.";s:16:"validation_error";s:61:"One or more fields have an error. Please check and try again.";s:4:"spam";s:71:"There was an error trying to send your message. Please try again later.";s:12:"accept_terms";s:69:"You must accept the terms and conditions before sending your message.";s:16:"invalid_required";s:22:"The field is required.";s:16:"invalid_too_long";s:22:"The field is too long.";s:17:"invalid_too_short";s:23:"The field is too short.";}'),
(368, 137, '_additional_settings', NULL),
(369, 137, '_locale', 'en_US'),
(370, 38, '_wp_trash_meta_status', 'draft'),
(371, 38, '_wp_trash_meta_time', '1464583064'),
(372, 38, '_wp_desired_post_slug', ''),
(373, 140, '_wp_attached_file', '2016/05/about-hero-2.jpg'),
(374, 140, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:4000;s:6:"height";i:2667;s:4:"file";s:24:"2016/05/about-hero-2.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"about-hero-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"about-hero-2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"about-hero-2-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"about-hero-2-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(390, 141, '_wp_attached_file', '2016/05/about-hero-3.jpg'),
(391, 141, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:4000;s:6:"height";i:2667;s:4:"file";s:24:"2016/05/about-hero-3.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"about-hero-3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"about-hero-3-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"about-hero-3-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"about-hero-3-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(404, 142, '_wp_attached_file', '2016/05/about-hero-4.jpg'),
(405, 142, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:4000;s:6:"height";i:2667;s:4:"file";s:24:"2016/05/about-hero-4.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"about-hero-4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"about-hero-4-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"about-hero-4-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"about-hero-4-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(415, 40, 'splash_hero', ''),
(416, 40, 'our_story', '<p class="p1"><span class="s1">Inhabitent Camping Supply Co. has been Vancouver baked-good icon for more than two whole months! Customers often comment on the bustle of activity they see in store…that’s where the magic happens every day.</span></p><p class="p1"><span class="s1">We want to bridge the gap between the comfort of city life and the lovely Instagram-worthiness of the great outdoors that surround us. We sell gear that’s fun and functional. So much fun, in fact, that you’ll want to pitch a tent inside your one-bedroom apartment so you can use it everyday.</span></p>'),
(417, 40, 'our_team', '<p class="p1"><span class="s1">Inhabitent Camping Supply Co.’s staff is made up of an amazing team of inspired retail associates. We really know our stuff when it comes to travel hammocks and campfire cooking gadgets. From a provincial park campground to the back-country, our staff knows what you need to outfit your outdoor outing.</span></p><p class="p1"><span class="s1">Our shop in nestled away in a lovely little corner of Vancouver. Pop in, say hi, and try out our tents!</span></p>') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2016-05-19 20:01:11', '2016-05-19 20:01:11', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2016-05-20 00:52:25', '2016-05-20 00:52:25', '', 0, 'http://localhost/student/?p=1', 0, 'post', '', 1),
(2, 1, '2016-05-19 20:01:11', '2016-05-19 20:01:11', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="//localhost:3000/inhabitents/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'journal', '', 'trash', 'closed', 'closed', '', 'sample-page__trashed', '', '', '2016-05-29 21:03:59', '2016-05-29 21:03:59', '', 0, 'http://localhost/student/?page_id=2', 0, 'page', '', 0),
(5, 1, '2016-04-16 23:32:33', '2016-04-16 23:32:33', '<p class="p1"><span class="s1">Ethical tumblr gentrify listicle roof party. Normcore jean shorts single-origin coffee aesthetic, selvage williamsburg chartreuse austin banjo tumblr trust fund. Vinyl freegan trust fund, blue bottle chicharrones VHS fanny pack pop-up tumblr put a bird on it blog whatever. Authentic next level shabby chic squid. Brooklyn chicharrones fanny pack waistcoat deep v. Distillery cronut man bun, readymade gluten-free fap listicle bespoke meh cray yuccie vinyl sartorial kogi. Pickled retro organic kale chips.</span></p>\r\n<p class="p1"><span class="s1">Shabby chic bicycle rights vinyl, ugh ennui wayfarers four dollar toast. Leggings beard ennui, bushwick mixtape next level meditation master cleanse bicycle rights single-origin coffee post-ironic kogi butcher. Cold-pressed yuccie knausgaard truffaut, messenger bag blog plaid seitan pork belly chambray echo park. PBR&amp;B direct trade lomo actually quinoa. Marfa you probably haven’t heard of them fanny pack, everyday carry craft beer ethical before they sold out bespoke pabst truffaut chicharrones pitchfork synth echo park biodiesel. Kinfolk disrupt four loko plaid, tumblr cold-pressed YOLO microdosing art party stumptown hammock. Fap man braid polaroid pug.</span></p>', 'Van Camping Photo Contest', '', 'publish', 'open', 'open', '', 'van-camping-photo-contest', '', '', '2016-05-19 23:36:05', '2016-05-19 23:36:05', '', 0, 'http://localhost/student/?p=5', 0, 'post', '', 0),
(6, 1, '2016-05-19 23:33:17', '2016-05-19 23:33:17', '', 'van-camper', '', 'inherit', 'open', 'closed', '', 'van-camper', '', '', '2016-05-19 23:33:17', '2016-05-19 23:33:17', '', 5, 'http://localhost/student/wp-content/uploads/2016/05/van-camper.jpg', 0, 'attachment', 'image/jpeg', 0),
(7, 1, '2016-05-19 23:36:05', '2016-05-19 23:36:05', '<p class="p1"><span class="s1">Ethical tumblr gentrify listicle roof party. Normcore jean shorts single-origin coffee aesthetic, selvage williamsburg chartreuse austin banjo tumblr trust fund. Vinyl freegan trust fund, blue bottle chicharrones VHS fanny pack pop-up tumblr put a bird on it blog whatever. Authentic next level shabby chic squid. Brooklyn chicharrones fanny pack waistcoat deep v. Distillery cronut man bun, readymade gluten-free fap listicle bespoke meh cray yuccie vinyl sartorial kogi. Pickled retro organic kale chips.</span></p>\r\n<p class="p1"><span class="s1">Shabby chic bicycle rights vinyl, ugh ennui wayfarers four dollar toast. Leggings beard ennui, bushwick mixtape next level meditation master cleanse bicycle rights single-origin coffee post-ironic kogi butcher. Cold-pressed yuccie knausgaard truffaut, messenger bag blog plaid seitan pork belly chambray echo park. PBR&amp;B direct trade lomo actually quinoa. Marfa you probably haven’t heard of them fanny pack, everyday carry craft beer ethical before they sold out bespoke pabst truffaut chicharrones pitchfork synth echo park biodiesel. Kinfolk disrupt four loko plaid, tumblr cold-pressed YOLO microdosing art party stumptown hammock. Fap man braid polaroid pug.</span></p>', 'Van Camping Photo Contest', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2016-05-19 23:36:05', '2016-05-19 23:36:05', '', 5, 'http://localhost/student/2016/05/19/5-revision-v1/', 0, 'revision', '', 0),
(8, 1, '2016-04-02 23:37:12', '2016-04-02 23:37:12', '<p class="p1"></p>\r\n<p class="p1"><span class="s1">Try-hard listicle truffaut locavore, pabst humblebrag bespoke flexitarian squid street art chia chicharrones. Gastropub portland cornhole poutine 90’s drinking vinegar, semiotics raw denim. Helvetica cornhole health goth pickled, portland banjo knausgaard drinking vinegar DIY YOLO trust fund tumblr skateboard church-key slow-carb. Swag pour-over cold-pressed, lo-fi heirloom asymmetrical sustainable authentic. Irony helvetica forage, mlkshk single-origin coffee scenester banjo jean shorts echo park hoodie ennui raw denim bitters tattooed plaid. Paleo quinoa mustache echo park, shoreditch scenester bitters chia shabby chic man braid tofu. Portland </span><span class="s1">man bun scenester, wolf master cleanse iPhone selfies readymade godard sustainable asymmetrical williamsburg.</span></p>\r\n<p class="p1"><span class="s1">Health goth ramps cold-pressed, literally etsy lomo fashion axe brunch dreamcatcher mlkshk vegan. Dreamcatcher squid shoreditch, kogi cold-pressed paleo four loko DIY umami keffiyeh. Blog green juice tofu yr chillwave taxidermy. Kinfolk aesthetic asymmetrical, waistcoat cray fashion axe keytar pork belly truffaut narwhal post-ironic squid listicle poutine. Twee quinoa brooklyn pour-over, beard wayfarers flannel. Shoreditch meditation ramps, tofu keytar etsy plaid bespoke. Yr synth poutine, farm-to-table raw denim mixtape everyday carry brunch scenester.</span></p>', 'Fireside Libations: 3 Warm Cocktail Recipes', '', 'publish', 'open', 'open', '', 'fireside-libations-3-warm-cocktail-recipes', '', '', '2016-05-19 23:43:09', '2016-05-19 23:43:09', '', 0, 'http://localhost/student/?p=8', 0, 'post', '', 0),
(10, 1, '2016-05-19 23:38:27', '2016-05-19 23:38:27', '', 'warm-cocktail', '', 'inherit', 'open', 'closed', '', 'warm-cocktail', '', '', '2016-05-19 23:38:27', '2016-05-19 23:38:27', '', 8, 'http://localhost/student/wp-content/uploads/2016/05/warm-cocktail.jpg', 0, 'attachment', 'image/jpeg', 0),
(11, 1, '2016-05-19 23:39:02', '2016-05-19 23:39:02', '<p class="p1"><span class="s1"><b>Published on:</b> April 2, 2016</span></p>\r\n<p class="p1"><span class="s1"><b>Categories:</b> Recipes</span></p>\r\n<p class="p1"><span class="s1"><b>Tags:</b> Campfires, Drinks</span></p>\r\n<p class="p1"><span class="s1">Try-hard listicle truffaut locavore, pabst humblebrag bespoke flexitarian squid street art chia chicharrones. Gastropub portland cornhole poutine 90’s drinking vinegar, semiotics raw denim. Helvetica cornhole health goth pickled, portland banjo knausgaard drinking vinegar DIY YOLO trust fund tumblr skateboard church-key slow-carb. Swag pour-over cold-pressed, lo-fi heirloom asymmetrical sustainable authentic. Irony helvetica forage, mlkshk single-origin coffee scenester banjo jean shorts echo park hoodie ennui raw denim bitters tattooed plaid. Paleo quinoa mustache echo park, shoreditch scenester bitters chia shabby chic man braid tofu. Portland</span></p>', 'Fireside Libations: 3 Warm Cocktail Recipes', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2016-05-19 23:39:02', '2016-05-19 23:39:02', '', 8, 'http://localhost/student/2016/05/19/8-revision-v1/', 0, 'revision', '', 0),
(14, 1, '2016-05-19 23:43:00', '2016-05-19 23:43:00', '<p class="p1"></p>\n<p class="p1"><span class="s1">Try-hard listicle truffaut locavore, pabst humblebrag bespoke flexitarian squid street art chia chicharrones. Gastropub portland cornhole poutine 90’s drinking vinegar, semiotics raw denim. Helvetica cornhole health goth pickled, portland banjo knausgaard drinking vinegar DIY YOLO trust fund tumblr skateboard church-key slow-carb. Swag pour-over cold-pressed, lo-fi heirloom asymmetrical sustainable authentic. Irony helvetica forage, mlkshk single-origin coffee scenester banjo jean shorts echo park hoodie ennui raw denim bitters tattooed plaid. Paleo quinoa mustache echo park, shoreditch scenester bitters chia shabby chic man braid tofu. Portland </span><span class="s1">man bun scenester, wolf master cleanse iPhone selfies readymade godard sustainable asymmetrical williamsburg.</span></p>\n<p class="p1"><span class="s1">Health goth ramps cold-pressed, literally etsy lomo fashion axe brunch dreamcatcher mlkshk vegan. Dreamcatcher squid shoreditch, kogi cold-pressed paleo four loko DIY umami keffiyeh. Blog green juice tofu yr chillwave taxidermy. Kinfolk aesthetic asymmetrical, waistcoat cray fashion axe keytar pork belly truffaut narwhal post-ironic squid listicle poutine. Twee quinoa brooklyn pour-over, beard wayfarers flannel. Shoreditch meditation ramps, tofu keytar etsy plaid bespoke. Yr synth poutine, farm-to-table raw denim mixtape everyday carry brunch scenester.</span></p>', 'Fireside Libations: 3 Warm Cocktail Recipes', '', 'inherit', 'closed', 'closed', '', '8-autosave-v1', '', '', '2016-05-19 23:43:00', '2016-05-19 23:43:00', '', 8, 'http://localhost/student/2016/05/19/8-autosave-v1/', 0, 'revision', '', 0),
(15, 1, '2016-05-19 23:40:20', '2016-05-19 23:40:20', '<p class="p1"></p>\r\n<p class="p1"><span class="s1">Try-hard listicle truffaut locavore, pabst humblebrag bespoke flexitarian squid street art chia chicharrones. Gastropub portland cornhole poutine 90’s drinking vinegar, semiotics raw denim. Helvetica cornhole health goth pickled, portland banjo knausgaard drinking vinegar DIY YOLO trust fund tumblr skateboard church-key slow-carb. Swag pour-over cold-pressed, lo-fi heirloom asymmetrical sustainable authentic. Irony helvetica forage, mlkshk single-origin coffee scenester banjo jean shorts echo park hoodie ennui raw denim bitters tattooed plaid. Paleo quinoa mustache echo park, shoreditch scenester bitters chia shabby chic man braid tofu. Portlan </span><span class="s1">man bun scenester, wolf master cleanse iPhone selfies readymade godard sustainable asymmetrical williamsburg.</span></p>\r\n<p class="p1"><span class="s1">Health goth ramps cold-pressed, literally etsy lomo fashion axe brunch dreamcatcher mlkshk vegan. Dreamcatcher squid shoreditch, kogi cold-pressed paleo four loko DIY umami keffiyeh. Blog green juice tofu yr chillwave taxidermy. Kinfolk aesthetic asymmetrical, waistcoat cray fashion axe keytar pork belly truffaut narwhal post-ironic squid listicle poutine. Twee quinoa brooklyn pour-over, beard wayfarers flannel. Shoreditch meditation ramps, tofu keytar etsy plaid bespoke. Yr synth poutine, farm-to-table raw denim mixtape everyday carry brunch scenester.</span></p>', 'Fireside Libations: 3 Warm Cocktail Recipes', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2016-05-19 23:40:20', '2016-05-19 23:40:20', '', 8, 'http://localhost/student/2016/05/19/8-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2016-05-19 23:40:20', '2016-05-19 23:40:20', '<p class="p1"><span class="s1"><b>Published on:</b> April 2, 2016</span></p>\r\n<p class="p1"><span class="s1"><b>Categories:</b> Recipes</span></p>\r\n<p class="p1"><span class="s1"><b>Tags:</b> Campfires, Drinks</span></p>\r\n<p class="p1"><span class="s1">Try-hard listicle truffaut locavore, pabst humblebrag bespoke flexitarian squid street art chia chicharrones. Gastropub portland cornhole poutine 90’s drinking vinegar, semiotics raw denim. Helvetica cornhole health goth pickled, portland banjo knausgaard drinking vinegar DIY YOLO trust fund tumblr skateboard church-key slow-carb. Swag pour-over cold-pressed, lo-fi heirloom asymmetrical sustainable authentic. Irony helvetica forage, mlkshk single-origin coffee scenester banjo jean shorts echo park hoodie ennui raw denim bitters tattooed plaid. Paleo quinoa mustache echo park, shoreditch scenester bitters chia shabby chic man braid tofu. Portland</span></p>', 'Fireside Libations: 3 Warm Cocktail Recipes', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2016-05-19 23:40:20', '2016-05-19 23:40:20', '', 8, 'http://localhost/student/2016/05/19/8-revision-v1/', 0, 'revision', '', 0),
(17, 1, '2016-05-19 23:41:38', '2016-05-19 23:41:38', '<p class="p1"></p>\r\n<p class="p1"><span class="s1">Try-hard listicle truffaut locavore, pabst humblebrag bespoke flexitarian squid street art chia chicharrones. Gastropub portland cornhole poutine 90’s drinking vinegar, semiotics raw denim. Helvetica cornhole health goth pickled, portland banjo knausgaard drinking vinegar DIY YOLO trust fund tumblr skateboard church-key slow-carb. Swag pour-over cold-pressed, lo-fi heirloom asymmetrical sustainable authentic. Irony helvetica forage, mlkshk single-origin coffee scenester banjo jean shorts echo park hoodie ennui raw denim bitters tattooed plaid. Paleo quinoa mustache echo park, shoreditch scenester bitters chia shabby chic man braid tofu. Portland </span><span class="s1">man bun scenester, wolf master cleanse iPhone selfies readymade godard sustainable asymmetrical williamsburg.</span></p>\r\n<p class="p1"><span class="s1">Health goth ramps cold-pressed, literally etsy lomo fashion axe brunch dreamcatcher mlkshk vegan. Dreamcatcher squid shoreditch, kogi cold-pressed paleo four loko DIY umami keffiyeh. Blog green juice tofu yr chillwave taxidermy. Kinfolk aesthetic asymmetrical, waistcoat cray fashion axe keytar pork belly truffaut narwhal post-ironic squid listicle poutine. Twee quinoa brooklyn pour-over, beard wayfarers flannel. Shoreditch meditation ramps, tofu keytar etsy plaid bespoke. Yr synth poutine, farm-to-table raw denim mixtape everyday carry brunch scenester.</span></p>', 'Fireside Libations: 3 Warm Cocktail Recipes', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2016-05-19 23:41:38', '2016-05-19 23:41:38', '', 8, 'http://localhost/student/2016/05/19/8-revision-v1/', 0, 'revision', '', 0),
(18, 1, '2016-05-19 23:41:38', '2016-05-19 23:41:38', '<p class="p1"><span class="s1"><b>Published on:</b> April 2, 2016</span></p>\r\n<p class="p1"><span class="s1"><b>Categories:</b> Recipes</span></p>\r\n<p class="p1"><span class="s1"><b>Tags:</b> Campfires, Drinks</span></p>\r\n<p class="p1"><span class="s1">Try-hard listicle truffaut locavore, pabst humblebrag bespoke flexitarian squid street art chia chicharrones. Gastropub portland cornhole poutine 90’s drinking vinegar, semiotics raw denim. Helvetica cornhole health goth pickled, portland banjo knausgaard drinking vinegar DIY YOLO trust fund tumblr skateboard church-key slow-carb. Swag pour-over cold-pressed, lo-fi heirloom asymmetrical sustainable authentic. Irony helvetica forage, mlkshk single-origin coffee scenester banjo jean shorts echo park hoodie ennui raw denim bitters tattooed plaid. Paleo quinoa mustache echo park, shoreditch scenester bitters chia shabby chic man braid tofu. Portland</span></p>', 'Fireside Libations: 3 Warm Cocktail Recipes', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2016-05-19 23:41:38', '2016-05-19 23:41:38', '', 8, 'http://localhost/student/2016/05/19/8-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2016-05-19 23:43:09', '2016-05-19 23:43:09', '<p class="p1"></p>\r\n<p class="p1"><span class="s1">Try-hard listicle truffaut locavore, pabst humblebrag bespoke flexitarian squid street art chia chicharrones. Gastropub portland cornhole poutine 90’s drinking vinegar, semiotics raw denim. Helvetica cornhole health goth pickled, portland banjo knausgaard drinking vinegar DIY YOLO trust fund tumblr skateboard church-key slow-carb. Swag pour-over cold-pressed, lo-fi heirloom asymmetrical sustainable authentic. Irony helvetica forage, mlkshk single-origin coffee scenester banjo jean shorts echo park hoodie ennui raw denim bitters tattooed plaid. Paleo quinoa mustache echo park, shoreditch scenester bitters chia shabby chic man braid tofu. Portland </span><span class="s1">man bun scenester, wolf master cleanse iPhone selfies readymade godard sustainable asymmetrical williamsburg.</span></p>\r\n<p class="p1"><span class="s1">Health goth ramps cold-pressed, literally etsy lomo fashion axe brunch dreamcatcher mlkshk vegan. Dreamcatcher squid shoreditch, kogi cold-pressed paleo four loko DIY umami keffiyeh. Blog green juice tofu yr chillwave taxidermy. Kinfolk aesthetic asymmetrical, waistcoat cray fashion axe keytar pork belly truffaut narwhal post-ironic squid listicle poutine. Twee quinoa brooklyn pour-over, beard wayfarers flannel. Shoreditch meditation ramps, tofu keytar etsy plaid bespoke. Yr synth poutine, farm-to-table raw denim mixtape everyday carry brunch scenester.</span></p>', 'Fireside Libations: 3 Warm Cocktail Recipes', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2016-05-19 23:43:09', '2016-05-19 23:43:09', '', 8, 'http://localhost/student/2016/05/19/8-revision-v1/', 0, 'revision', '', 0),
(20, 1, '2016-03-31 00:47:33', '2016-03-31 00:47:33', '<p class="p1"><b></b><span class="s1">Paleo semiotics gastropub messenger bag, kogi beard tattooed truffaut cred artisan. Skateboard cliche selfies fashion axe, viral ugh vinyl plaid before they sold out squid jean shorts tofu letterpress. Kombucha gluten-free banh mi authentic paleo, kale chips typewriter kogi normcore mustache cliche before they sold out intelligentsia poutine 90’s. Fixie mlkshk put a bird on it messenger bag cardigan, gochujang cronut health goth tousled truffaut humblebrag keytar you probably haven’t heard of them chillwave. Put a bird on it flexitarian cornhole leggings umami. Umami polaroid gentrify distillery tacos flannel green juice.</span></p>\r\n<p class="p1"><span class="s1">Truffaut twee master cleanse, drinking vinegar poutine +1 letterpress fanny pack. Truffaut dreamcatcher church-key 90’s bicycle rights. Actually tumblr fingerstache schlitz trust fund keffiyeh. Gastropub pitchfork jean shorts paleo, photo booth 90’s yr drinking vinegar shoreditch vice iPhone 3 wolf moon neutra craft beer taxidermy. Cronut YOLO readymade man bun, trust fund kale chips meggings four loko chia blue bottle raw denim wayfarers beard. Authentic freegan waistcoat hoodie. Hashtag dreamcatcher pickled, locavore messenger bag banh mi tousled man braid ennui.</span></p>', 'How To: Eating Healthy Meals in the Wild', '', 'publish', 'open', 'open', '', 'how-to-eating-healthy-meals-in-the-wild', '', '', '2016-05-20 00:50:25', '2016-05-20 00:50:25', '', 0, 'http://localhost/student/?p=20', 0, 'post', '', 0),
(21, 1, '2016-03-31 00:47:35', '2016-03-31 00:47:35', '', 'How To: Eating Healthy Meals in the Wild', '', 'trash', 'open', 'open', '', 'how-to-eating-healthy-meals-in-the-wild-2__trashed', '', '', '2016-05-20 00:51:50', '2016-05-20 00:51:50', '', 0, 'http://localhost/student/?p=21', 0, 'post', '', 0),
(22, 1, '2016-05-20 00:50:03', '2016-05-20 00:50:03', '', 'healthy-camp-food', '', 'inherit', 'open', 'closed', '', 'healthy-camp-food', '', '', '2016-05-20 00:50:03', '2016-05-20 00:50:03', '', 20, 'http://localhost/student/wp-content/uploads/2016/05/healthy-camp-food.jpg', 0, 'attachment', 'image/jpeg', 0),
(23, 1, '2016-05-20 00:50:25', '2016-05-20 00:50:25', '<p class="p1"><b></b><span class="s1">Paleo semiotics gastropub messenger bag, kogi beard tattooed truffaut cred artisan. Skateboard cliche selfies fashion axe, viral ugh vinyl plaid before they sold out squid jean shorts tofu letterpress. Kombucha gluten-free banh mi authentic paleo, kale chips typewriter kogi normcore mustache cliche before they sold out intelligentsia poutine 90’s. Fixie mlkshk put a bird on it messenger bag cardigan, gochujang cronut health goth tousled truffaut humblebrag keytar you probably haven’t heard of them chillwave. Put a bird on it flexitarian cornhole leggings umami. Umami polaroid gentrify distillery tacos flannel green juice.</span></p>\r\n<p class="p1"><span class="s1">Truffaut twee master cleanse, drinking vinegar poutine +1 letterpress fanny pack. Truffaut dreamcatcher church-key 90’s bicycle rights. Actually tumblr fingerstache schlitz trust fund keffiyeh. Gastropub pitchfork jean shorts paleo, photo booth 90’s yr drinking vinegar shoreditch vice iPhone 3 wolf moon neutra craft beer taxidermy. Cronut YOLO readymade man bun, trust fund kale chips meggings four loko chia blue bottle raw denim wayfarers beard. Authentic freegan waistcoat hoodie. Hashtag dreamcatcher pickled, locavore messenger bag banh mi tousled man braid ennui.</span></p>', 'How To: Eating Healthy Meals in the Wild', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2016-05-20 00:50:25', '2016-05-20 00:50:25', '', 20, 'http://localhost/student/2016/05/20/20-revision-v1/', 0, 'revision', '', 0),
(24, 1, '2016-05-20 00:50:31', '2016-05-20 00:50:31', '', 'How To: Eating Healthy Meals in the Wild', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2016-05-20 00:50:31', '2016-05-20 00:50:31', '', 21, 'http://localhost/student/2016/05/20/21-revision-v1/', 0, 'revision', '', 0),
(25, 1, '2016-05-20 00:52:25', '2016-05-20 00:52:25', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2016-05-20 00:52:25', '2016-05-20 00:52:25', '', 1, 'http://localhost/student/2016/05/20/1-revision-v1/', 0, 'revision', '', 0),
(26, 1, '2016-03-19 00:52:31', '2016-03-19 00:52:31', '<p class="p1"></p>\r\n<p class="p3"><span class="s1">Wayfarers VHS chambray schlitz, ramps semiotics post-ironic franzen fixie wolf polaroid viral. Blue bottle scenester paleo bitters, master cleanse put a bird on it PBR&amp;B brunch kinfolk echo park pitchfork YOLO. Forage biodiesel polaroid beard, scenester normcore actually swag food truck meggings. Readymade cornhole pabst gastropub. Roof party put a bird on it quinoa, bicycle rights kickstarter venmo master cleanse. Sustainable keffiyeh leggings, farm-to-table cliche banh mi drinking vinegar. Crucifix tote bag pork belly, before they sold out artisan YOLO listicle kombucha gluten-free vice shoreditch actually swag direct trade.</span></p>\r\n<p class="p3"><span class="s1">Venmo XOXO meh hella raw denim. Migas listicle photo booth, wayfarers single-origin coffee artisan gastropub iPhone echo park. Banjo forage kale chips tilde semiotics echo park artisan art party, meditation viral retro pitchfork. Seitan tacos cray waistcoat, migas pickled fap try-hard gentrify narwhal pinterest thundercats keffiyeh. Keffiyeh hashtag tofu slow-carb, yr pork belly VHS normcore typewriter gastropub letterpress echo park. Ugh sriracha messenger bag umami, mixtape vice flexitarian forage iPhone synth sustainable banjo. Banh mi humblebrag shoreditch, single-origin coffee butcher skateboard farm-to-table bicycle rights.</span></p>', '5 Tips for Solo Camping', '', 'publish', 'open', 'open', '', '5-tips-for-solo-camping', '', '', '2016-05-20 00:55:17', '2016-05-20 00:55:17', '', 0, 'http://localhost/student/?p=26', 0, 'post', '', 0),
(27, 1, '2016-05-20 00:54:45', '2016-05-20 00:54:45', '', 'solo-camping', '', 'inherit', 'open', 'closed', '', 'solo-camping', '', '', '2016-05-20 00:54:45', '2016-05-20 00:54:45', '', 26, 'http://localhost/student/wp-content/uploads/2016/05/solo-camping.jpg', 0, 'attachment', 'image/jpeg', 0),
(28, 1, '2016-05-20 00:55:17', '2016-05-20 00:55:17', '<p class="p1"></p>\r\n<p class="p3"><span class="s1">Wayfarers VHS chambray schlitz, ramps semiotics post-ironic franzen fixie wolf polaroid viral. Blue bottle scenester paleo bitters, master cleanse put a bird on it PBR&amp;B brunch kinfolk echo park pitchfork YOLO. Forage biodiesel polaroid beard, scenester normcore actually swag food truck meggings. Readymade cornhole pabst gastropub. Roof party put a bird on it quinoa, bicycle rights kickstarter venmo master cleanse. Sustainable keffiyeh leggings, farm-to-table cliche banh mi drinking vinegar. Crucifix tote bag pork belly, before they sold out artisan YOLO listicle kombucha gluten-free vice shoreditch actually swag direct trade.</span></p>\r\n<p class="p3"><span class="s1">Venmo XOXO meh hella raw denim. Migas listicle photo booth, wayfarers single-origin coffee artisan gastropub iPhone echo park. Banjo forage kale chips tilde semiotics echo park artisan art party, meditation viral retro pitchfork. Seitan tacos cray waistcoat, migas pickled fap try-hard gentrify narwhal pinterest thundercats keffiyeh. Keffiyeh hashtag tofu slow-carb, yr pork belly VHS normcore typewriter gastropub letterpress echo park. Ugh sriracha messenger bag umami, mixtape vice flexitarian forage iPhone synth sustainable banjo. Banh mi humblebrag shoreditch, single-origin coffee butcher skateboard farm-to-table bicycle rights.</span></p>', '5 Tips for Solo Camping', '', 'inherit', 'closed', 'closed', '', '26-revision-v1', '', '', '2016-05-20 00:55:17', '2016-05-20 00:55:17', '', 26, 'http://localhost/student/2016/05/20/26-revision-v1/', 0, 'revision', '', 0),
(29, 1, '2016-05-20 00:57:22', '2016-05-20 00:57:22', '<p class="p1"></p>\r\n<p class="p3"><span class="s1">Fashion axe schlitz selvage, art party fixie ugh skateboard fap keffiyeh intelligentsia gastropub tattooed humblebrag brunch shabby chic. Tilde selvage ennui, ethical sartorial keytar gastropub mlkshk. Migas seitan lumbersexual, paleo kogi sriracha photo booth hoodie franzen. XOXO fap master cleanse everyday carry, four loko helvetica marfa. Tousled health goth normcore, raw denim banh mi bespoke quinoa. Readymade keytar iPhone fashion axe, raw denim put a bird on it 3 wolf moon plaid fap you probably haven’t heard of them gentrify tumblr kickstarter seitan. Stumptown cold-pressed green juice, vinyl roof party mixtape gluten-free fashion axe kickstarter kitsch.</span></p>\r\n<p class="p3"><span class="s1">Kogi mixtape tousled chicharrones art party kinfolk. Synth vinyl tote bag food truck mumblecore roof party, fashion axe heirloom wolf twee butcher marfa gentrify keytar neutra. Scenester cardigan twee, gochujang butcher ugh blog before they sold out chambray sriracha cold-pressed fanny pack kitsch jean shorts. Master cleanse man bun flannel, locavore lo-fi hashtag next level wolf thundercats cronut man braid helvetica jean shorts listicle. XOXO kogi health goth, jean shorts scenester pug waistcoat shabby chic fap polaroid church-key organic brunch flexitarian. Yuccie lo-fi hammock VHS, waistcoat hashtag post-ironic gochujang helvetica paleo four loko kogi meh cray sartorial. Flexitarian paleo health goth freegan blue bottle.</span></p>\r\n<p class="p3"><span class="s1">Viral hashtag deep v, iPhone street art tacos helvetica semiotics sustainable man braid paleo affogato raw denim flexitarian mumblecore. Bicycle rights shabby chic humblebrag small batch pop-up. Slow-carb bespoke biodiesel sartorial migas fashion axe, mumblecore pop-up tumblr. Gentrify YOLO cray art party occupy, readymade wolf mustache. Food truck tacos microdosing poutine, kombucha YOLO mumblecore. Freegan typewriter distillery truffaut. Portland slow-carb hammock, yuccie cardigan before they sold out organic blog messenger bag tattooed church-key biodiesel XOXO tumblr.</span></p>', 'Glamping Made Easy', '', 'publish', 'open', 'open', '', 'glamping-made-easy', '', '', '2016-05-20 00:57:22', '2016-05-20 00:57:22', '', 0, 'http://localhost/student/?p=29', 0, 'post', '', 0),
(30, 1, '2016-05-20 00:57:00', '2016-05-20 00:57:00', '', 'glamping', '', 'inherit', 'open', 'closed', '', 'glamping', '', '', '2016-05-20 00:57:00', '2016-05-20 00:57:00', '', 29, 'http://localhost/student/wp-content/uploads/2016/05/glamping.jpg', 0, 'attachment', 'image/jpeg', 0),
(31, 1, '2016-05-20 00:57:22', '2016-05-20 00:57:22', '<p class="p1"></p>\r\n<p class="p3"><span class="s1">Fashion axe schlitz selvage, art party fixie ugh skateboard fap keffiyeh intelligentsia gastropub tattooed humblebrag brunch shabby chic. Tilde selvage ennui, ethical sartorial keytar gastropub mlkshk. Migas seitan lumbersexual, paleo kogi sriracha photo booth hoodie franzen. XOXO fap master cleanse everyday carry, four loko helvetica marfa. Tousled health goth normcore, raw denim banh mi bespoke quinoa. Readymade keytar iPhone fashion axe, raw denim put a bird on it 3 wolf moon plaid fap you probably haven’t heard of them gentrify tumblr kickstarter seitan. Stumptown cold-pressed green juice, vinyl roof party mixtape gluten-free fashion axe kickstarter kitsch.</span></p>\r\n<p class="p3"><span class="s1">Kogi mixtape tousled chicharrones art party kinfolk. Synth vinyl tote bag food truck mumblecore roof party, fashion axe heirloom wolf twee butcher marfa gentrify keytar neutra. Scenester cardigan twee, gochujang butcher ugh blog before they sold out chambray sriracha cold-pressed fanny pack kitsch jean shorts. Master cleanse man bun flannel, locavore lo-fi hashtag next level wolf thundercats cronut man braid helvetica jean shorts listicle. XOXO kogi health goth, jean shorts scenester pug waistcoat shabby chic fap polaroid church-key organic brunch flexitarian. Yuccie lo-fi hammock VHS, waistcoat hashtag post-ironic gochujang helvetica paleo four loko kogi meh cray sartorial. Flexitarian paleo health goth freegan blue bottle.</span></p>\r\n<p class="p3"><span class="s1">Viral hashtag deep v, iPhone street art tacos helvetica semiotics sustainable man braid paleo affogato raw denim flexitarian mumblecore. Bicycle rights shabby chic humblebrag small batch pop-up. Slow-carb bespoke biodiesel sartorial migas fashion axe, mumblecore pop-up tumblr. Gentrify YOLO cray art party occupy, readymade wolf mustache. Food truck tacos microdosing poutine, kombucha YOLO mumblecore. Freegan typewriter distillery truffaut. Portland slow-carb hammock, yuccie cardigan before they sold out organic blog messenger bag tattooed church-key biodiesel XOXO tumblr.</span></p>', 'Glamping Made Easy', '', 'inherit', 'closed', 'closed', '', '29-revision-v1', '', '', '2016-05-20 00:57:22', '2016-05-20 00:57:22', '', 29, 'http://localhost/student/2016/05/20/29-revision-v1/', 0, 'revision', '', 0),
(32, 1, '2016-05-20 18:09:27', '2016-05-20 18:09:27', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://localhost/student/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Blog', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2016-05-20 18:09:27', '2016-05-20 18:09:27', '', 2, 'http://localhost/student/2016/05/20/2-revision-v1/', 0, 'revision', '', 0),
(33, 1, '2016-05-20 18:10:24', '2016-05-20 18:10:24', '', 'Home', '', 'trash', 'closed', 'closed', '', 'home__trashed', '', '', '2016-05-29 19:50:58', '2016-05-29 19:50:58', '', 0, 'http://localhost/student/?page_id=33', 0, 'page', '', 0),
(34, 1, '2016-05-20 18:10:24', '2016-05-20 18:10:24', '', 'Home', '', 'inherit', 'closed', 'closed', '', '33-revision-v1', '', '', '2016-05-20 18:10:24', '2016-05-20 18:10:24', '', 33, 'http://localhost/student/2016/05/20/33-revision-v1/', 0, 'revision', '', 0),
(35, 1, '2016-05-24 21:05:23', '2016-05-24 21:05:23', 'This is a Test Product', 'Test Product', '', 'trash', 'closed', 'closed', '', 'test-product__trashed', '', '', '2016-05-25 22:04:32', '2016-05-25 22:04:32', '', 0, 'http://localhost/student/?post_type=product&#038;p=35', 0, 'product', '', 0),
(36, 1, '2016-05-24 21:05:23', '2016-05-24 21:05:23', 'This is a Test Product', 'Test Product', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2016-05-24 21:05:23', '2016-05-24 21:05:23', '', 35, 'http://localhost/student/2016/05/24/35-revision-v1/', 0, 'revision', '', 0),
(37, 1, '2016-05-24 21:45:46', '2016-05-24 21:45:46', '', 'Product Fields', '', 'publish', 'closed', 'closed', '', 'product-fields', '', '', '2016-05-24 21:45:46', '2016-05-24 21:45:46', '', 0, 'http://localhost/student/?post_type=cfs&#038;p=37', 0, 'cfs', '', 0),
(38, 1, '2016-05-25 17:01:24', '2016-05-25 17:01:24', '', 'About Page', '', 'trash', 'closed', 'closed', '', '__trashed', '', '', '2016-05-30 04:37:44', '2016-05-30 04:37:44', '', 0, 'http://localhost/student/?post_type=cfs&#038;p=38', 0, 'cfs', '', 0),
(39, 1, '2016-05-25 17:04:00', '2016-05-25 17:04:00', '', 'About Page', '', 'publish', 'closed', 'closed', '', 'about-page', '', '', '2016-05-30 04:38:21', '2016-05-30 04:38:21', '', 0, 'http://localhost/student/?post_type=cfs&#038;p=39', 0, 'cfs', '', 0),
(40, 1, '2016-05-25 17:04:25', '2016-05-25 17:04:25', '', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2016-05-30 15:19:40', '2016-05-30 15:19:40', '', 0, 'http://localhost/student/?page_id=40', 0, 'page', '', 0),
(41, 1, '2016-05-25 17:04:25', '2016-05-25 17:04:25', '', 'About', '', 'inherit', 'closed', 'closed', '', '40-revision-v1', '', '', '2016-05-25 17:04:25', '2016-05-25 17:04:25', '', 40, 'http://localhost/student/2016/05/25/40-revision-v1/', 0, 'revision', '', 0),
(42, 1, '2016-05-25 17:05:15', '2016-05-25 17:05:15', '', 'about-hero', '', 'inherit', 'open', 'closed', '', 'about-hero', '', '', '2016-05-25 17:05:15', '2016-05-25 17:05:15', '', 40, 'http://localhost/student/wp-content/uploads/2016/05/about-hero.jpg', 0, 'attachment', 'image/jpeg', 0),
(43, 1, '2016-05-25 17:05:59', '2016-05-25 17:05:59', '', 'about-hero', '', 'inherit', 'open', 'closed', '', 'about-hero-2', '', '', '2016-05-25 17:05:59', '2016-05-25 17:05:59', '', 40, 'http://localhost/student/wp-content/uploads/2016/05/about-hero-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(45, 1, '2016-05-25 21:54:25', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-05-25 21:54:25', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=45', 0, 'post', '', 0),
(46, 1, '2016-05-25 21:54:56', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2016-05-25 21:54:56', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?post_type=product&p=46', 0, 'product', '', 0),
(47, 1, '2016-05-25 22:02:21', '2016-05-25 22:02:21', '<p class="p1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Beach Tent', '', 'publish', 'closed', 'closed', '', 'beach-tent', '', '', '2016-05-25 22:04:03', '2016-05-25 22:04:03', '', 0, 'http://localhost/student/?post_type=product&#038;p=47', 0, 'product', '', 0),
(48, 1, '2016-05-25 22:02:21', '2016-05-25 22:02:21', '<p class="p1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Beach Tent', '', 'inherit', 'closed', 'closed', '', '47-revision-v1', '', '', '2016-05-25 22:02:21', '2016-05-25 22:02:21', '', 47, 'http://localhost/student/2016/05/25/47-revision-v1/', 0, 'revision', '', 0),
(49, 1, '2016-05-25 22:03:29', '2016-05-25 22:03:29', '', 'beach-tent', '', 'inherit', 'open', 'closed', '', 'beach-tent-2', '', '', '2016-05-25 22:03:29', '2016-05-25 22:03:29', '', 47, 'http://localhost/student/wp-content/uploads/2016/05/beach-tent.jpg', 0, 'attachment', 'image/jpeg', 0),
(50, 1, '2016-05-25 22:11:26', '2016-05-25 22:11:26', '<p class="p1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Camper Van', '', 'publish', 'closed', 'closed', '', 'camper-van', '', '', '2016-05-25 22:13:40', '2016-05-25 22:13:40', '', 0, 'http://localhost/student/?post_type=product&#038;p=50', 0, 'product', '', 0),
(51, 1, '2016-05-25 22:11:26', '2016-05-25 22:11:26', '<p class="p1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Camper Van', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2016-05-25 22:11:26', '2016-05-25 22:11:26', '', 50, 'http://localhost/student/2016/05/25/50-revision-v1/', 0, 'revision', '', 0),
(52, 1, '2016-05-25 22:12:32', '2016-05-25 22:12:32', '', 'camper-van', '', 'inherit', 'open', 'closed', '', 'camper-van-2', '', '', '2016-05-25 22:12:32', '2016-05-25 22:12:32', '', 50, 'http://localhost/student/wp-content/uploads/2016/05/camper-van.jpg', 0, 'attachment', 'image/jpeg', 0),
(53, 1, '2016-05-25 22:12:33', '2016-05-25 22:12:33', '', 'ceramic-mugs', '', 'inherit', 'open', 'closed', '', 'ceramic-mugs', '', '', '2016-05-25 22:12:33', '2016-05-25 22:12:33', '', 50, 'http://localhost/student/wp-content/uploads/2016/05/ceramic-mugs.jpg', 0, 'attachment', 'image/jpeg', 0),
(54, 1, '2016-05-25 22:12:34', '2016-05-25 22:12:34', '', 'film-cameras', '', 'inherit', 'open', 'closed', '', 'film-cameras', '', '', '2016-05-25 22:12:34', '2016-05-25 22:12:34', '', 50, 'http://localhost/student/wp-content/uploads/2016/05/film-cameras.jpg', 0, 'attachment', 'image/jpeg', 0),
(55, 1, '2016-05-25 22:12:36', '2016-05-25 22:12:36', '', 'flannel-shirt', '', 'inherit', 'open', 'closed', '', 'flannel-shirt', '', '', '2016-05-25 22:12:36', '2016-05-25 22:12:36', '', 50, 'http://localhost/student/wp-content/uploads/2016/05/flannel-shirt.jpg', 0, 'attachment', 'image/jpeg', 0),
(56, 1, '2016-05-25 22:12:37', '2016-05-25 22:12:37', '', 'gas-stove', '', 'inherit', 'open', 'closed', '', 'gas-stove', '', '', '2016-05-25 22:12:37', '2016-05-25 22:12:37', '', 50, 'http://localhost/student/wp-content/uploads/2016/05/gas-stove.jpg', 0, 'attachment', 'image/jpeg', 0),
(57, 1, '2016-05-25 22:12:39', '2016-05-25 22:12:39', '', 'hand-knit-toque', '', 'inherit', 'open', 'closed', '', 'hand-knit-toque', '', '', '2016-05-25 22:12:39', '2016-05-25 22:12:39', '', 50, 'http://localhost/student/wp-content/uploads/2016/05/hand-knit-toque.jpg', 0, 'attachment', 'image/jpeg', 0),
(58, 1, '2016-05-25 22:12:40', '2016-05-25 22:12:40', '', 'hiking-boots', '', 'inherit', 'open', 'closed', '', 'hiking-boots', '', '', '2016-05-25 22:12:40', '2016-05-25 22:12:40', '', 50, 'http://localhost/student/wp-content/uploads/2016/05/hiking-boots.jpg', 0, 'attachment', 'image/jpeg', 0),
(59, 1, '2016-05-25 22:12:41', '2016-05-25 22:12:41', '', 'large-thermos', '', 'inherit', 'open', 'closed', '', 'large-thermos', '', '', '2016-05-25 22:12:41', '2016-05-25 22:12:41', '', 50, 'http://localhost/student/wp-content/uploads/2016/05/large-thermos.jpg', 0, 'attachment', 'image/jpeg', 0),
(60, 1, '2016-05-25 22:12:43', '2016-05-25 22:12:43', '', 'leather-satchel', '', 'inherit', 'open', 'closed', '', 'leather-satchel', '', '', '2016-05-25 22:12:43', '2016-05-25 22:12:43', '', 50, 'http://localhost/student/wp-content/uploads/2016/05/leather-satchel.jpg', 0, 'attachment', 'image/jpeg', 0),
(61, 1, '2016-05-25 22:12:44', '2016-05-25 22:12:44', '', 'nylon-tents', '', 'inherit', 'open', 'closed', '', 'nylon-tents', '', '', '2016-05-25 22:12:44', '2016-05-25 22:12:44', '', 50, 'http://localhost/student/wp-content/uploads/2016/05/nylon-tents.jpg', 0, 'attachment', 'image/jpeg', 0),
(62, 1, '2016-05-25 22:12:45', '2016-05-25 22:12:45', '', 'rustic-tools', '', 'inherit', 'open', 'closed', '', 'rustic-tools', '', '', '2016-05-25 22:12:45', '2016-05-25 22:12:45', '', 50, 'http://localhost/student/wp-content/uploads/2016/05/rustic-tools.jpg', 0, 'attachment', 'image/jpeg', 0),
(63, 1, '2016-05-25 22:12:47', '2016-05-25 22:12:47', '', 'stew-can', '', 'inherit', 'open', 'closed', '', 'stew-can', '', '', '2016-05-25 22:12:47', '2016-05-25 22:12:47', '', 50, 'http://localhost/student/wp-content/uploads/2016/05/stew-can.jpg', 0, 'attachment', 'image/jpeg', 0),
(64, 1, '2016-05-25 22:12:48', '2016-05-25 22:12:48', '', 'travel-hammock', '', 'inherit', 'open', 'closed', '', 'travel-hammock', '', '', '2016-05-25 22:12:48', '2016-05-25 22:12:48', '', 50, 'http://localhost/student/wp-content/uploads/2016/05/travel-hammock.jpg', 0, 'attachment', 'image/jpeg', 0),
(65, 1, '2016-05-25 22:12:50', '2016-05-25 22:12:50', '', 'weathered-canoes', '', 'inherit', 'open', 'closed', '', 'weathered-canoes', '', '', '2016-05-25 22:12:50', '2016-05-25 22:12:50', '', 50, 'http://localhost/student/wp-content/uploads/2016/05/weathered-canoes.jpg', 0, 'attachment', 'image/jpeg', 0),
(66, 1, '2016-05-25 22:12:51', '2016-05-25 22:12:51', '', 'wood-ax', '', 'inherit', 'open', 'closed', '', 'wood-ax', '', '', '2016-05-25 22:12:51', '2016-05-25 22:12:51', '', 50, 'http://localhost/student/wp-content/uploads/2016/05/wood-ax.jpg', 0, 'attachment', 'image/jpeg', 0),
(67, 1, '2016-05-25 22:44:35', '2016-05-25 22:44:35', '<p class="p1"><span class="s1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</span></p>', 'Ceramic Mug', '', 'publish', 'closed', 'closed', '', 'ceramic-mug', '', '', '2016-05-25 22:44:35', '2016-05-25 22:44:35', '', 0, 'http://localhost/student/?post_type=product&#038;p=67', 0, 'product', '', 0),
(68, 1, '2016-05-25 22:44:35', '2016-05-25 22:44:35', '<p class="p1"><span class="s1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</span></p>', 'Ceramic Mug', '', 'inherit', 'closed', 'closed', '', '67-revision-v1', '', '', '2016-05-25 22:44:35', '2016-05-25 22:44:35', '', 67, 'http://localhost/student/2016/05/25/67-revision-v1/', 0, 'revision', '', 0),
(69, 1, '2016-05-25 22:47:15', '2016-05-25 22:47:15', '<p class="p1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Film Camera', '', 'publish', 'closed', 'closed', '', 'film-camera', '', '', '2016-05-25 22:47:15', '2016-05-25 22:47:15', '', 0, 'http://localhost/student/?post_type=product&#038;p=69', 0, 'product', '', 0),
(70, 1, '2016-05-25 22:47:15', '2016-05-25 22:47:15', '<p class="p1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Film Camera', '', 'inherit', 'closed', 'closed', '', '69-revision-v1', '', '', '2016-05-25 22:47:15', '2016-05-25 22:47:15', '', 69, 'http://localhost/student/2016/05/25/69-revision-v1/', 0, 'revision', '', 0),
(71, 1, '2016-05-25 23:15:42', '2016-05-25 23:15:42', '<p class="p1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Gas Stove', '', 'publish', 'closed', 'closed', '', 'gas-stove', '', '', '2016-05-29 21:31:35', '2016-05-29 21:31:35', '', 0, 'http://localhost/student/?post_type=product&#038;p=71', 0, 'product', '', 0),
(72, 1, '2016-05-25 23:15:42', '2016-05-25 23:15:42', '<p class="p1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Gas Stove', '', 'inherit', 'closed', 'closed', '', '71-revision-v1', '', '', '2016-05-25 23:15:42', '2016-05-25 23:15:42', '', 71, 'http://localhost/student/2016/05/25/71-revision-v1/', 0, 'revision', '', 0),
(73, 1, '2016-05-25 23:16:42', '2016-05-25 23:16:42', '<p class="p3">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Hand-Knit Toque', '', 'publish', 'closed', 'closed', '', 'hand-knit-toque', '', '', '2016-05-29 21:31:06', '2016-05-29 21:31:06', '', 0, 'http://localhost/student/?post_type=product&#038;p=73', 0, 'product', '', 0),
(74, 1, '2016-05-25 23:16:42', '2016-05-25 23:16:42', '<p class="p3">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Hand-Knit Toque', '', 'inherit', 'closed', 'closed', '', '73-revision-v1', '', '', '2016-05-25 23:16:42', '2016-05-25 23:16:42', '', 73, 'http://localhost/student/2016/05/25/73-revision-v1/', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(75, 1, '2016-05-25 23:17:46', '2016-05-25 23:17:46', '<p class="p1"><span class="s1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</span></p>', 'Hiking Boots', '', 'publish', 'closed', 'closed', '', 'hiking-boots', '', '', '2016-05-29 21:30:43', '2016-05-29 21:30:43', '', 0, 'http://localhost/student/?post_type=product&#038;p=75', 0, 'product', '', 0),
(76, 1, '2016-05-25 23:17:46', '2016-05-25 23:17:46', '<p class="p1"><span class="s1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</span></p>', 'Hiking Boots', '', 'inherit', 'closed', 'closed', '', '75-revision-v1', '', '', '2016-05-25 23:17:46', '2016-05-25 23:17:46', '', 75, 'http://localhost/student/2016/05/25/75-revision-v1/', 0, 'revision', '', 0),
(77, 1, '2016-05-25 23:19:28', '2016-05-25 23:19:28', '<p class="p1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Large Thermos', '', 'publish', 'closed', 'closed', '', 'large-thermos', '', '', '2016-05-29 21:30:21', '2016-05-29 21:30:21', '', 0, 'http://localhost/student/?post_type=product&#038;p=77', 0, 'product', '', 0),
(78, 1, '2016-05-25 23:19:28', '2016-05-25 23:19:28', '<p class="p1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Large Thermos', '', 'inherit', 'closed', 'closed', '', '77-revision-v1', '', '', '2016-05-25 23:19:28', '2016-05-25 23:19:28', '', 77, 'http://localhost/student/2016/05/25/77-revision-v1/', 0, 'revision', '', 0),
(79, 1, '2016-05-25 23:20:06', '2016-05-25 23:20:06', '<p class="p1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Leather Satchel', '', 'publish', 'closed', 'closed', '', 'leather-satchel', '', '', '2016-05-29 21:29:55', '2016-05-29 21:29:55', '', 0, 'http://localhost/student/?post_type=product&#038;p=79', 0, 'product', '', 0),
(80, 1, '2016-05-25 23:20:06', '2016-05-25 23:20:06', '<p class="p1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Leather Satchel', '', 'inherit', 'closed', 'closed', '', '79-revision-v1', '', '', '2016-05-25 23:20:06', '2016-05-25 23:20:06', '', 79, 'http://localhost/student/2016/05/25/79-revision-v1/', 0, 'revision', '', 0),
(81, 1, '2016-05-25 23:23:04', '2016-05-25 23:23:04', '<p class="p1"><span class="s1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</span></p>', 'Nylon Tents', '', 'publish', 'closed', 'closed', '', 'nylon-tents', '', '', '2016-05-29 21:29:28', '2016-05-29 21:29:28', '', 0, 'http://localhost/student/?post_type=product&#038;p=81', 0, 'product', '', 0),
(82, 1, '2016-05-25 23:23:04', '2016-05-25 23:23:04', '<p class="p1"><span class="s1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</span></p>', 'Nylon Tents', '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', '2016-05-25 23:23:04', '2016-05-25 23:23:04', '', 81, 'http://localhost/student/2016/05/25/81-revision-v1/', 0, 'revision', '', 0),
(83, 1, '2016-05-25 23:25:35', '2016-05-25 23:25:35', '<p class="p3">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Rustic Tools', '', 'publish', 'closed', 'closed', '', 'rustic-tools', '', '', '2016-05-29 21:28:58', '2016-05-29 21:28:58', '', 0, 'http://localhost/student/?post_type=product&#038;p=83', 0, 'product', '', 0),
(84, 1, '2016-05-25 23:25:35', '2016-05-25 23:25:35', '<p class="p3">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Rustic Tools', '', 'inherit', 'closed', 'closed', '', '83-revision-v1', '', '', '2016-05-25 23:25:35', '2016-05-25 23:25:35', '', 83, 'http://localhost/student/2016/05/25/83-revision-v1/', 0, 'revision', '', 0),
(85, 1, '2016-05-25 23:29:38', '2016-05-25 23:29:38', '<p class="p1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Stew Can', '', 'publish', 'closed', 'closed', '', 'stew-can', '', '', '2016-05-29 21:28:21', '2016-05-29 21:28:21', '', 0, 'http://localhost/student/?post_type=product&#038;p=85', 0, 'product', '', 0),
(86, 1, '2016-05-25 23:29:38', '2016-05-25 23:29:38', '<p class="p1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Stew Can', '', 'inherit', 'closed', 'closed', '', '85-revision-v1', '', '', '2016-05-25 23:29:38', '2016-05-25 23:29:38', '', 85, 'http://localhost/student/2016/05/25/85-revision-v1/', 0, 'revision', '', 0),
(87, 1, '2016-05-25 23:30:37', '2016-05-25 23:30:37', '<p class="p3"><span class="s1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</span></p>', 'Travel Hammock', '', 'publish', 'closed', 'closed', '', 'travel-hammock', '', '', '2016-05-29 21:28:37', '2016-05-29 21:28:37', '', 0, 'http://localhost/student/?post_type=product&#038;p=87', 0, 'product', '', 0),
(88, 1, '2016-05-25 23:30:37', '2016-05-25 23:30:37', '<p class="p1"></p>\r\n<p class="p3"><span class="s1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</span></p>', 'Travel Hammock', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2016-05-25 23:30:37', '2016-05-25 23:30:37', '', 87, 'http://localhost/student/2016/05/25/87-revision-v1/', 0, 'revision', '', 0),
(89, 1, '2016-05-25 23:33:34', '2016-05-25 23:33:34', '<p class="p1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Weathered Canoes', '', 'publish', 'closed', 'closed', '', 'weathered-canoes', '', '', '2016-05-29 21:28:02', '2016-05-29 21:28:02', '', 0, 'http://localhost/student/?post_type=product&#038;p=89', 0, 'product', '', 0),
(90, 1, '2016-05-25 23:33:34', '2016-05-25 23:33:34', '<p class="p1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Weathered Canoes', '', 'inherit', 'closed', 'closed', '', '89-revision-v1', '', '', '2016-05-25 23:33:34', '2016-05-25 23:33:34', '', 89, 'http://localhost/student/2016/05/25/89-revision-v1/', 0, 'revision', '', 0),
(91, 1, '2016-05-25 23:34:11', '2016-05-25 23:34:11', '<p class="p1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Wood Ax', '', 'publish', 'closed', 'closed', '', 'wood-ax', '', '', '2016-05-25 23:34:11', '2016-05-25 23:34:11', '', 0, 'http://localhost/student/?post_type=product&#038;p=91', 0, 'product', '', 0),
(92, 1, '2016-05-25 23:34:11', '2016-05-25 23:34:11', '<p class="p1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</p>', 'Wood Ax', '', 'inherit', 'closed', 'closed', '', '91-revision-v1', '', '', '2016-05-25 23:34:11', '2016-05-25 23:34:11', '', 91, 'http://localhost/student/2016/05/25/91-revision-v1/', 0, 'revision', '', 0),
(93, 1, '2016-05-25 23:34:14', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2016-05-25 23:34:14', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?post_type=product&p=93', 0, 'product', '', 0),
(94, 1, '2016-05-29 19:52:09', '2016-05-29 19:52:09', '', 'Journal', '', 'trash', 'closed', 'closed', '', 'journal__trashed', '', '', '2016-05-29 19:53:02', '2016-05-29 19:53:02', '', 0, 'http://localhost/student/?page_id=94', 0, 'page', '', 0),
(95, 1, '2016-05-27 23:07:16', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-05-27 23:07:16', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=95', 0, 'post', '', 0),
(96, 1, '2016-05-29 19:03:13', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2016-05-29 19:03:13', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?page_id=96', 0, 'page', '', 0),
(97, 1, '2016-05-29 19:04:57', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2016-05-29 19:04:57', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?page_id=97', 0, 'page', '', 0),
(98, 1, '2016-05-29 19:05:44', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2016-05-29 19:05:44', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?page_id=98', 0, 'page', '', 0),
(99, 1, '2016-05-29 19:06:03', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2016-05-29 19:06:03', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?page_id=99', 0, 'page', '', 0),
(100, 1, '2016-05-29 19:11:57', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2016-05-29 19:11:57', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?page_id=100', 0, 'page', '', 0),
(101, 1, '2016-05-29 19:13:02', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2016-05-29 19:13:02', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?page_id=101', 0, 'page', '', 0),
(102, 1, '2016-05-29 19:13:18', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2016-05-29 19:13:18', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?page_id=102', 0, 'page', '', 0),
(103, 1, '2016-05-29 19:14:49', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2016-05-29 19:14:49', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?page_id=103', 0, 'page', '', 0),
(104, 1, '2016-05-29 19:15:11', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2016-05-29 19:15:11', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?page_id=104', 0, 'page', '', 0),
(105, 1, '2016-05-29 19:15:43', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2016-05-29 19:15:43', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?page_id=105', 0, 'page', '', 0),
(106, 1, '2016-05-29 19:22:50', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2016-05-29 19:22:50', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?page_id=106', 0, 'page', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(107, 1, '2016-05-29 19:25:12', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2016-05-29 19:25:12', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?page_id=107', 0, 'page', '', 0),
(108, 1, '2016-05-29 19:54:42', '2016-05-29 19:54:42', '', 'Find Us', '', 'trash', 'closed', 'closed', '', 'find-us-2__trashed', '', '', '2016-05-29 19:54:59', '2016-05-29 19:54:59', '', 0, 'http://localhost/student/?page_id=108', 0, 'page', '', 0),
(109, 1, '2016-05-29 19:52:09', '2016-05-29 19:52:09', '', 'Journal', '', 'inherit', 'closed', 'closed', '', '94-revision-v1', '', '', '2016-05-29 19:52:09', '2016-05-29 19:52:09', '', 94, 'http://localhost/student/2016/05/29/94-revision-v1/', 0, 'revision', '', 0),
(110, 1, '2016-05-29 19:53:22', '2016-05-29 19:53:22', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="//localhost:3000/inhabitents/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'journal', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2016-05-29 19:53:22', '2016-05-29 19:53:22', '', 2, 'http://localhost/student/2016/05/29/2-revision-v1/', 0, 'revision', '', 0),
(111, 1, '2016-05-29 19:54:38', '2016-05-29 19:54:38', '\r\n\r\n\r\n<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2603.6833050880123!2d-123.1403569843112!3d49.26344827932922!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x548673c79e1ac457%3A0x3aea6428fa30dc6a!2s1490+W+Broadway%2C+Vancouver%2C+BC+V6H!5e0!3m2!1sen!2sca!4v1464566595643" width="760" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>\r\n\r\n[contact-form-7 id="137" title="Contact form 1"]', 'Find Us', '', 'publish', 'closed', 'closed', '', 'find-us', '', '', '2016-05-30 00:03:47', '2016-05-30 00:03:47', '', 0, 'http://localhost/student/?page_id=111', 0, 'page', '', 0),
(112, 1, '2016-05-29 19:54:38', '2016-05-29 19:54:38', '', 'Find Us', '', 'inherit', 'closed', 'closed', '', '111-revision-v1', '', '', '2016-05-29 19:54:38', '2016-05-29 19:54:38', '', 111, 'http://localhost/student/2016/05/29/111-revision-v1/', 0, 'revision', '', 0),
(113, 1, '2016-05-29 19:54:42', '2016-05-29 19:54:42', '', 'Find Us', '', 'inherit', 'closed', 'closed', '', '108-revision-v1', '', '', '2016-05-29 19:54:42', '2016-05-29 19:54:42', '', 108, 'http://localhost/student/2016/05/29/108-revision-v1/', 0, 'revision', '', 0),
(114, 1, '2016-05-29 19:56:09', '2016-05-29 19:56:09', '', 'shop', '', 'publish', 'closed', 'closed', '', 'products', '', '', '2016-05-29 21:26:17', '2016-05-29 21:26:17', '', 0, 'http://localhost/student/?page_id=114', 0, 'page', '', 0),
(115, 1, '2016-05-29 19:56:09', '2016-05-29 19:56:09', '', 'shop', '', 'inherit', 'closed', 'closed', '', '114-revision-v1', '', '', '2016-05-29 19:56:09', '2016-05-29 19:56:09', '', 114, 'http://localhost/student/2016/05/29/114-revision-v1/', 0, 'revision', '', 0),
(116, 1, '2016-05-29 21:03:29', '2016-05-29 21:03:29', '', 'journal', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2016-05-29 21:03:29', '2016-05-29 21:03:29', '', 2, 'http://localhost/student/2016/05/29/2-revision-v1/', 0, 'revision', '', 0),
(117, 1, '2016-05-29 21:03:29', '2016-05-29 21:03:29', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="//localhost:3000/inhabitents/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'journal', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2016-05-29 21:03:29', '2016-05-29 21:03:29', '', 2, 'http://localhost/student/2016/05/29/2-revision-v1/', 0, 'revision', '', 0),
(118, 1, '2016-05-29 21:04:13', '2016-05-29 21:04:13', '', 'Journal', '', 'publish', 'closed', 'closed', '', 'journal', '', '', '2016-05-29 21:04:13', '2016-05-29 21:04:13', '', 0, 'http://localhost/student/?page_id=118', 0, 'page', '', 0),
(119, 1, '2016-05-29 21:04:13', '2016-05-29 21:04:13', '', 'Journal', '', 'inherit', 'closed', 'closed', '', '118-revision-v1', '', '', '2016-05-29 21:04:13', '2016-05-29 21:04:13', '', 118, 'http://localhost/student/2016/05/29/118-revision-v1/', 0, 'revision', '', 0),
(120, 1, '2016-05-29 21:10:08', '2016-05-29 21:10:08', '', 'home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2016-05-29 21:10:08', '2016-05-29 21:10:08', '', 0, 'http://localhost/student/?page_id=120', 0, 'page', '', 0),
(121, 1, '2016-05-29 21:10:08', '2016-05-29 21:10:08', '', 'home', '', 'inherit', 'closed', 'closed', '', '120-revision-v1', '', '', '2016-05-29 21:10:08', '2016-05-29 21:10:08', '', 120, 'http://localhost/student/2016/05/29/120-revision-v1/', 0, 'revision', '', 0),
(122, 1, '2016-05-29 21:18:11', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-29 21:18:11', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=122', 1, 'nav_menu_item', '', 0),
(123, 1, '2016-05-29 21:18:11', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-29 21:18:11', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=123', 1, 'nav_menu_item', '', 0),
(124, 1, '2016-05-29 21:18:11', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-29 21:18:11', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=124', 1, 'nav_menu_item', '', 0),
(125, 1, '2016-05-29 21:18:11', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-29 21:18:11', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=125', 1, 'nav_menu_item', '', 0),
(126, 1, '2016-05-29 21:18:11', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-29 21:18:11', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=126', 1, 'nav_menu_item', '', 0),
(127, 1, '2016-05-29 21:18:11', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-29 21:18:11', '0000-00-00 00:00:00', '', 0, 'http://localhost/student/?p=127', 1, 'nav_menu_item', '', 0),
(129, 1, '2016-05-29 21:19:53', '2016-05-29 21:19:53', ' ', '', '', 'publish', 'closed', 'closed', '', '129', '', '', '2016-05-29 21:22:18', '2016-05-29 21:22:18', '', 0, 'http://localhost/student/?p=129', 3, 'nav_menu_item', '', 0),
(130, 1, '2016-05-29 21:19:53', '2016-05-29 21:19:53', ' ', '', '', 'publish', 'closed', 'closed', '', '130', '', '', '2016-05-29 21:22:18', '2016-05-29 21:22:18', '', 0, 'http://localhost/student/?p=130', 4, 'nav_menu_item', '', 0),
(132, 1, '2016-05-29 21:19:53', '2016-05-29 21:19:53', ' ', '', '', 'publish', 'closed', 'closed', '', '132', '', '', '2016-05-29 21:22:18', '2016-05-29 21:22:18', '', 0, 'http://localhost/student/?p=132', 2, 'nav_menu_item', '', 0),
(133, 1, '2016-05-29 21:19:53', '2016-05-29 21:19:53', ' ', '', '', 'publish', 'closed', 'closed', '', '133', '', '', '2016-05-29 21:22:18', '2016-05-29 21:22:18', '', 0, 'http://localhost/student/?p=133', 1, 'nav_menu_item', '', 0),
(134, 1, '2016-05-29 21:28:37', '2016-05-29 21:28:37', '<p class="p3"><span class="s1">Gastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.</span></p>', 'Travel Hammock', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2016-05-29 21:28:37', '2016-05-29 21:28:37', '', 87, 'http://localhost/student/2016/05/29/87-revision-v1/', 0, 'revision', '', 0),
(135, 1, '2016-05-29 21:34:04', '2016-05-29 21:34:04', '<header class="entry-header">\r\n<h1 class="entry-title"></h1>\r\n</header>\r\n<div class="entry-content">\r\n\r\nGastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.\r\n\r\n</div>', 'FLANNEL SHIRT', '', 'publish', 'closed', 'closed', '', 'flannel-shirt', '', '', '2016-05-29 21:34:04', '2016-05-29 21:34:04', '', 0, 'http://localhost/student/?post_type=product&#038;p=135', 0, 'product', '', 0),
(136, 1, '2016-05-29 21:34:04', '2016-05-29 21:34:04', '<header class="entry-header">\r\n<h1 class="entry-title"></h1>\r\n</header>\r\n<div class="entry-content">\r\n\r\nGastropub forage irony, hashtag affogato ennui kogi. Forage four loko iPhone, raw denim pop-up taxidermy etsy gluten-free +1 bespoke paleo semiotics. Narwhal salvia ennui, echo park flexitarian tousled ethical twee. Listicle fanny pack bicycle rights drinking vinegar, bitters readymade hella jean shorts cray four dollar toast. Pug trust fund chambray brunch irony chartreuse. Cliche intelligentsia brooklyn retro. Actually readymade keytar mumblecore direct trade, twee kombucha iPhone.\r\n\r\n</div>', 'FLANNEL SHIRT', '', 'inherit', 'closed', 'closed', '', '135-revision-v1', '', '', '2016-05-29 21:34:04', '2016-05-29 21:34:04', '', 135, 'http://localhost/student/2016/05/29/135-revision-v1/', 0, 'revision', '', 0),
(137, 1, '2016-05-30 00:02:12', '2016-05-30 00:02:12', '<p>Your Name (required)<br />\n    [text* your-name] </p>\n\n<p>Your Email (required)<br />\n    [email* your-email] </p>\n\n<p>Subject<br />\n    [text your-subject] </p>\n\n<p>Your Message<br />\n    [textarea your-message] </p>\n\n<p>[submit "Send"]</p>\ninhabitents "[your-subject]"\n[your-name] <hunter_w@live.ca>\nFrom: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n--\nThis e-mail was sent from a contact form on inhabitents (http://localhost/student)\nhunter_w@live.ca\nReply-To: [your-email]\n\n0\n0\n\ninhabitents "[your-subject]"\ninhabitents <hunter_w@live.ca>\nMessage Body:\n[your-message]\n\n--\nThis e-mail was sent from a contact form on inhabitents (http://localhost/student)\n[your-email]\nReply-To: hunter_w@live.ca\n\n0\n0\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.', 'Contact form 1', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2016-05-30 00:02:12', '2016-05-30 00:02:12', '', 0, 'http://localhost/student/?post_type=wpcf7_contact_form&p=137', 0, 'wpcf7_contact_form', '', 0),
(138, 1, '2016-05-30 00:03:34', '2016-05-30 00:03:34', '\n\n\n\n\n[contact-form-7 id="137" title="Contact form 1"]', 'Find Us', '', 'inherit', 'closed', 'closed', '', '111-autosave-v1', '', '', '2016-05-30 00:03:34', '2016-05-30 00:03:34', '', 111, 'http://localhost/student/2016/05/30/111-autosave-v1/', 0, 'revision', '', 0),
(139, 1, '2016-05-30 00:03:47', '2016-05-30 00:03:47', '\r\n\r\n\r\n<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2603.6833050880123!2d-123.1403569843112!3d49.26344827932922!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x548673c79e1ac457%3A0x3aea6428fa30dc6a!2s1490+W+Broadway%2C+Vancouver%2C+BC+V6H!5e0!3m2!1sen!2sca!4v1464566595643" width="760" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>\r\n\r\n[contact-form-7 id="137" title="Contact form 1"]', 'Find Us', '', 'inherit', 'closed', 'closed', '', '111-revision-v1', '', '', '2016-05-30 00:03:47', '2016-05-30 00:03:47', '', 111, 'http://localhost/student/2016/05/30/111-revision-v1/', 0, 'revision', '', 0),
(140, 1, '2016-05-30 15:11:27', '2016-05-30 15:11:27', '', 'about-hero', '', 'inherit', 'open', 'closed', '', 'about-hero-3', '', '', '2016-05-30 15:11:27', '2016-05-30 15:11:27', '', 40, 'http://localhost/student/wp-content/uploads/2016/05/about-hero-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(141, 1, '2016-05-30 15:15:47', '2016-05-30 15:15:47', '', 'about-hero', '', 'inherit', 'open', 'closed', '', 'about-hero-4', '', '', '2016-05-30 15:15:47', '2016-05-30 15:15:47', '', 40, 'http://localhost/student/wp-content/uploads/2016/05/about-hero-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(142, 1, '2016-05-30 15:19:23', '2016-05-30 15:19:23', '', 'about-hero', '', 'inherit', 'open', 'closed', '', 'about-hero-5', '', '', '2016-05-30 15:19:23', '2016-05-30 15:19:23', '', 40, 'http://localhost/student/wp-content/uploads/2016/05/about-hero-4.jpg', 0, 'attachment', 'image/jpeg', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(5, 2, 0),
(5, 3, 0),
(5, 4, 0),
(8, 5, 0),
(8, 6, 0),
(8, 7, 0),
(20, 5, 0),
(20, 8, 0),
(20, 9, 0),
(21, 5, 0),
(21, 9, 0),
(26, 11, 0),
(26, 12, 0),
(29, 11, 0),
(29, 12, 0),
(29, 13, 0),
(47, 17, 0),
(50, 17, 0),
(69, 16, 0),
(71, 18, 0),
(73, 19, 0),
(75, 19, 0),
(77, 18, 0),
(79, 19, 0),
(81, 17, 0),
(83, 16, 0),
(85, 18, 0),
(87, 17, 0),
(89, 16, 0),
(91, 16, 0),
(129, 20, 0),
(130, 20, 0),
(132, 20, 0),
(133, 20, 0),
(135, 19, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'category', '', 0, 1),
(3, 3, 'post_tag', '', 0, 1),
(4, 4, 'post_tag', '', 0, 1),
(5, 5, 'category', '', 0, 2),
(6, 6, 'post_tag', '', 0, 1),
(7, 7, 'post_tag', '', 0, 1),
(8, 8, 'post_tag', '', 0, 1),
(9, 9, 'post_tag', '', 0, 1),
(10, 10, 'category', '', 0, 0),
(11, 11, 'category', '', 0, 2),
(12, 12, 'post_tag', '', 0, 2),
(13, 13, 'category', '', 0, 1),
(16, 16, 'product-type', 'Get back to nature with the tools and toys you need to enjoy the great outdoors', 0, 4),
(17, 17, 'product-type', ' a good night’s rest in the wild in a home away from home that travels well.', 0, 4),
(18, 18, 'product-type', 'Nothing beats food cooked over a fire. We have all you need for good camping eats.', 0, 3),
(19, 19, 'product-type', 'From flannel shirts to toques, look the part while roughing it in the great outdoors.', 0, 4),
(20, 20, 'nav_menu', '', 0, 4) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Contests', 'contests', 0),
(3, 'Photography', 'photography', 0),
(4, 'Vans', 'vans', 0),
(5, 'Recipes', 'recipes', 0),
(6, 'Campfires', 'campfires', 0),
(7, 'Drinks', 'drinks', 0),
(8, 'Food', 'food', 0),
(9, 'Healthy', 'healthy', 0),
(10, 'Tenting', 'tenting', 0),
(11, 'How-tos', 'how-tos', 0),
(12, 'Tenting', 'tenting', 0),
(13, 'Not Really Camping', 'not-really-camping', 0),
(16, 'Do', 'do', 0),
(17, 'Sleep', 'sleep', 0),
(18, 'Eat', 'eat', 0),
(19, 'Wear', 'wear', 0),
(20, 'Menu 1', 'menu-1', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'hunterfuture'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'wp_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', ''),
(13, 1, 'show_welcome_panel', '1'),
(14, 1, 'session_tokens', 'a:3:{s:64:"74fc46aace616a24a1eedecca9e589b5d474842b1f718318a25e575da64da34a";a:4:{s:10:"expiration";i:1464897689;s:2:"ip";s:3:"::1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36";s:5:"login";i:1463688089;}s:64:"d184c9a072e0fafcca5c73556ada532288fd966a10577c9c19c40d1c4a76d344";a:4:{s:10:"expiration";i:1464292797;s:2:"ip";s:3:"::1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36";s:5:"login";i:1464119997;}s:64:"5d4b25d855858a2d8ea294a841d96b31e1f729a9a8d86db02ac8e00445dae821";a:4:{s:10:"expiration";i:1465493616;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36";s:5:"login";i:1464284016;}}'),
(15, 1, 'wp_dashboard_quick_press_last_post_id', '95'),
(16, 1, 'wp_user-settings', 'libraryContent=browse&editor=html'),
(17, 1, 'wp_user-settings-time', '1464566623'),
(18, 1, 'closedpostboxes_post', 'a:0:{}'),
(19, 1, 'metaboxhidden_post', 'a:6:{i:0;s:11:"postexcerpt";i:1;s:13:"trackbacksdiv";i:2;s:10:"postcustom";i:3;s:16:"commentstatusdiv";i:4;s:7:"slugdiv";i:5;s:9:"authordiv";}'),
(20, 1, 'closedpostboxes_product', 'a:0:{}'),
(21, 1, 'metaboxhidden_product', 'a:1:{i:0;s:7:"slugdiv";}'),
(22, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(23, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:21:"add-post-type-product";i:1;s:12:"add-post_tag";i:2;s:16:"add-product-type";}'),
(24, 1, 'nav_menu_recently_edited', '20'),
(25, 1, 'closedpostboxes_page', 'a:0:{}'),
(26, 1, 'metaboxhidden_page', 'a:5:{i:0;s:10:"postcustom";i:1;s:16:"commentstatusdiv";i:2;s:11:"commentsdiv";i:3;s:7:"slugdiv";i:4;s:9:"authordiv";}'),
(27, 2, 'nickname', 'mandi'),
(28, 2, 'first_name', 'mandi'),
(29, 2, 'last_name', 'wise'),
(30, 2, 'description', ''),
(31, 2, 'rich_editing', 'true'),
(32, 2, 'comment_shortcuts', 'false'),
(33, 2, 'admin_color', 'fresh'),
(34, 2, 'use_ssl', '0'),
(35, 2, 'show_admin_bar_front', 'true'),
(36, 2, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(37, 2, 'wp_user_level', '10'),
(38, 2, 'dismissed_wp_pointers', '') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'hunterfuture', '$P$BlWteBottB2Dyh/su2UcnvpTGn10Dc1', 'hunterfuture', 'hunter_w@live.ca', '', '2016-05-19 20:01:11', '', 0, 'hunterfuture'),
(2, 'mandi', '$P$B5zFD8yjnju0O/..2A681lvpvNjhEl/', 'mandi', 'mandi@redacademy.com', '', '2016-05-30 15:39:45', '1464622785:$P$B6xHgNatwDC8YVPCMoscgD7EFKEnMj0', 0, 'mandi wise') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

